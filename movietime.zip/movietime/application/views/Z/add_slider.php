<html>
<head>
<title>Bitly</title>
<strong style="color:#F33" >
<h2 align="center">Add Slider !!</h2>
</strong>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body >
<table class="table-hover" >
  <div class="container">
    <h2>Add Slider</h2>
    <form name="f1" id="f1" method="post"   action="<?php echo site_url()?>/toC/add_slider_ok" enctype="multipart/form-data">
    <div class="row">
        <div class="form-group col-sm-4">
          <label for="url"><strong style="color: #00F" >Title : </strong></label>
          <input type="text" class="form-control" id="link" placeholder="Name " name="title" required>
        </div>
      </div>
      <div class="button clearfix" ></div>
      <div class="row">
        <div class="form-group  col-sm-5">
          <label for="pwd" id=""><strong style="color:#F33" title="Generate Custon URL !!" >Description : </strong> </label>
          <input type="text" class="form-control"  id="custom_url" placeholder="About" name="about"  >
        </div>
      </div>
      
      <div class="row">
        <div class="form-group  col-sm-3">
          <label for="pwd" id=""><strong style="color:#63F" title="Generate Custon URL !!" >Choose Image : </strong> </label>
          <input type="file" class="form-control" name="img" accept="image/*" >
        </div>
      </div>
      
      <button type="submit" class="btn btn-primary" id="add"  name="add" >Add </button>
      <button type="button" class="btn btn-info" id="print"  name="print" onclick="javascript:window.print();" >Print <i class="fa fa-print"></i></button>
    </form>
  </div>
</table>
</body>
</html>
