<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css"  >
<link rel="stylesheet" href="<?php echo base_url()?>assets/datatable/datatables.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/datatable/datatables.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/sweetalert/sweetalert.css">
<script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/0.4.2/sweet-alert.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/0.4.2/sweet-alert.css">
<!--<link href="https://fonts.googleapis.com/css?family=Bungee+Inline" rel="stylesheet"><style>body {font-family: 'Bungee Inline', cursive;}</style>-->
<body>

<div class="main-panel">
  <nav class="navbar navbar-transparent navbar-absolute">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a class="navbar-brand" > Hello Welcome <strong><?php echo $this->session->userdata('em');?> </strong></a> <a href="<?php echo site_url()?>/movietime/logout">
        <button type="button" class="btn btn-success pull-right" title="log out">Log out</button>
        </a> </div>
      <div class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li> <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown"> <i class="material-icons">dashboard</i>
            <p class="hidden-lg hidden-md">Dashboard</p>
            </a> </li>
          <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="material-icons">notifications</i> <span class="notification">5</span>
            <p class="hidden-lg hidden-md">Notifications</p>
            </a>
            <ul class="dropdown-menu">
              <li> <a href="#">Mike John responded to your email</a> </li>
              <li> <a href="#">You have 5 new tasks</a> </li>
              <li> <a href="#">You're now friend with jj</a> </li>
              <li> <a href="#">Another Notification</a> </li>
              <li> <a href="#">Another One</a> </li>
            </ul>
          </li>
          <li> <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown"> <i class="material-icons">person</i>
            <p class="hidden-lg hidden-md">Profile</p>
            </a> </li>
        </ul>
        <form class="navbar-form navbar-right" name="search" role="search" required action="<?php echo site_url()?>/movietime/search">
          <div class="form-group  is-empty">
            <input type="text" class="form-control" placeholder="Search">
            <span class="material-input"></span> </div>
          <button type="submit" class="btn btn-white btn-round btn-just-icon"> <i class="material-icons">search</i>
          <div class="ripple-container"></div>
          </button>
        </form>
      </div>
    </div>
  </nav>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header" data-background-color="purple">
              <h4 class="title">Movie List Table</h4>
              <p class="category">Contains All movie data in this table !!!</p>
            </div>
            <div class="card-content table-responsive">
              <form name="f13" id="f13" enctype="multipart/form-data" action="<?php echo site_url()?>/movietime/multiDel" method="post">
                <table  id="example" class="display"  style="width:100%">
                  <a href="<?php echo site_url()?>/toC/addmovie">
                  <button type="button" class="btn btn-success pull-right" title="add">Add New Movie</button>
                  </a>
                  <thead class="text-primary">
                  <th>#</th>
                    <th>ID</th>
                    <th >Title</th>
                    <th>Director</th>
                    <th>Category</th>
                    <th>Duration</th>
                   <th>IMG</th>
                    <th colspan="2">Action</th>
                      </thead>
                  <tbody id="org">
                    <?php foreach($vv as $a) {  ?>
                    <tr>
                    <td><input type="checkbox" class="checkbox" name="chk[]"  value="<?php echo $a->id ?>" ></td>
                      <td><?php echo $a->id ?></td>
                      <td><?php echo $a->title ?></td>
                      <td><?php echo $a->director ?></td>
                      <td><?php echo $a->genere ?></td>
                      <td><?php echo $a->duration ?></td>
                      <!--<td ><?php //echo $a->image ?></td>-->
                     <td class="nowrap" ><img src="<?php echo base_url()?>./data/<?php echo $a->image?>" style="height:55px;width:55px;" alt="<?php echo $a->id ?>" class="image-responsive" ></td>
                      <td><button type="button" name="del" class="btn btn-danger" value="<?php echo $a->id ?>" onClick="deleteok(this)"  >Delete</button>
                       || <a href="<?php echo site_url()?>/movietime/editmovie/<?php echo $a->id?>">
                       <button type="button" name="edit" class="btn btn-info" >Edit</button></a></td>
                    </tr>
                    <?php }?>
                  </tbody>
                </table>
                <button type="submit" class="btn btn-primary pull-middle" title="Delete_Selected ">Delete Selected </button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-12">
          <div class="card card-plain">
            <div class="card-header" data-background-color="purple">
              <h4 class="title">All shows Table</h4>
              <p class="category">Contains shows Details</p>
            </div>
            <div class="card-content table-responsive">
              <table class="table table-hover" width="">
                <a href="<?php echo site_url()?>/movietime/addshow">
                <button type="button" class="btn btn-success pull-right" title="add new">Add Show</button>
                </a>
                <thead>
                <th>ID</th>
                  <th>Name</th>
                  <th>Screen</th>
                  <th>Slot</th>
                  <th>Booked</th>
                    </thead>
                <tbody>
                  <?php foreach($cc as $a) { ?>
                  <tr>
                    <td><?php echo $a->id ?></td>
                    <td><?php echo $a->MId ?> || <?php echo $a->title ?></td>
                    <td><?php echo $a->screen ?></td>
                    <td><?php echo $a->slot ?></td>
                    <td><?php echo $a->booked ?></td>
                    <td><a href="<?php echo site_url()?>/movietime/deleteShow/<?php echo $a->id?>">Delete </a> |||| 
                    <a href="<?php echo site_url()?>/movietime/editShow/<?php echo $a->id?>">Edit </a></td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>



</body><!--   Core JS Files   -->

<script src="<?php echo base_url()?>assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/js/material.min.js" type="text/javascript"></script>
<!--  Charts Plugin -->
<script src="<?php echo base_url()?>assets/js/chartist.min.js"></script>
<!--  Dynamic Elements plugin -->
<script src="<?php echo base_url()?>assets/js/arrive.min.js"></script>
<!--  PerfectScrollbar Library -->
<script src="<?php echo base_url()?>assets/js/perfect-scrollbar.jquery.min.js"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo base_url()?>assets/js/bootstrap-notify.js"></script>

<!-- Material Dashboard javascript methods -->
<script src="<?php echo base_url()?>assets/js/material-dashboard.js?v=1.2.0"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo base_url()?>assets/js/demo.js">
</script>

<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">D3GsT3$.-U  */(.pSe!.90-=ggE/-*</script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>-->
  
<script src="<?php echo base_url()?>assets/js/jquery-3.2.1.min.js"  type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"  type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/datatable/js/jquery.dataTables.min.js"  type="text/javascript"></script>

<script type="text/javascript" class="init">
$(document).ready(function() {
  $('#example').dataTable({
"aoColumnDefs": [
{ "bSortable": false,
	"aTargets": [ 6,7]
	} ]
});
} );
</script>
<script type="text/javascript" >
window.onload=hidesortbyTitle;



function hidesortbyTitle()
{  $('#first').hide();$('#org').show(); }
function showsortbyTitle()
{  $('#first').show();$('#org').hide(); }
</script>



<script>

function deleteok(a)
{
    var id= a.value;
	  swal({
            title: "Are you sure?",
            text: "Do You Really want to delele this ?? ",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, Delete this !",
			cancelButtonText: "No  !!", 
            closeOnConfirm: false ,
			closeOnCancel: true
			},
			 function(isConfirm)
        {  if (isConfirm) { 
            swal("Deleted!", "This Item has been Deleted.", "success");
            $(location).attr('href','<?php echo site_url() ?>/movietime/delete/'+id);
		  }  }
    );
}
 </script>

<script>
/*
function confirmDelete(id){
     //   var id=29;
     swal({   title: "Are you sure?",  
		 text: "Your will not be able to recover this file!", 
		   type: "warning",   showCancelButton: true,  
		   confirmButtonColor: "#DD6B55", 
			confirmButtonText: "Yes, delete it!",  
			 cancelButtonText: "No, cancel Please !", 
			closeOnConfirm: true,  
		 closeOnCancel: false }, 
		 
function (isConfirm) {
            $.ajax({
              url:"<?php //echo site_url() ?>/movietime/delete/"+id,
                type: "GET",
                data: {"id":id},
                dataType:"html",
                success: function () {
                    swal("Done!", "It was succesfully deleted!", "success");
                },
                error: function (xhr, ajaxOptions, thrownError) {
               	swal("Error deleting!", "Please try again", "error");
				
                }
            });
        });
    } 


               

/*function swal({
  title: "Are you sure?",
  text: "Your will not be able to recover this imaginary file!",
  type: "warning",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Yes, delete it!",
  closeOnConfirm: false
});
function deleteconfirm(id){
				$.ajax({
							url:"<?php //echo site_url() ?>/movietime/delete/"+id,
							success: function(swal){
							swal("Deleted!", "Your imaginary file has been deleted.", "success");
							}
					});
			}*/
</script>





</body>
</html>