<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url()?>/assets/img/apple-icon.png" />
<link rel="icon" type="image/png" href="<?php echo base_url()?>/assets/img/favicon.png" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>Material Dashboard by Creative Tim</title>
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
<meta name="viewport" content="width=device-width" />
<!-- Bootstrap core CSS     -->
<link href="<?php echo base_url()?>/assets/css/bootstrap.min.css" rel="stylesheet" />
<!--  Material Dashboard CSS    -->
<link href="<?php echo base_url()?>/assets/css/material-dashboard.css?v=1.2.0" rel="stylesheet" />
<!--  CSS for Demo Purpose, don't include it in your project     -->
<link href="<?php echo base_url()?>/assets/css/demo.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">

<!--     Fonts and icons     -->
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>
</head>

<body>
<div class="main-panel">
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header" data-background-color="purple">
              <h4 class="title">Add New Movie Details !!</h4>
            </div>
            <div class="card-content">
              <form name="f1" id="f1" enctype="multipart/form-data" method="post">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group label-floating">
                      <label class="control-label">Title</label>
                      <input type="text" class="form-control" name="title" id="title" value="Type Any Title" >
                      <strong style="color:Red" id="tt" ></strong> </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group label-floating">
                      <label class="control-label">Genere ( Category )</label>
                      <input type="text" class="form-control" name="genere" id="genere" value="Type Any Category" >
                      <p style="color:red" id="gen"></p>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group label-floating">
                      <label class="control-label">Duration</label>
                      <input type="number" class="form-control"  name="duration" id="duration" min="20" max="200" value="108">
                      <p style="color:red" id="dur"></p>
                    </div>
                  </div>
                </div>
                <?php $fi = $this->db->list_tables();
			  foreach ($fi as $field)
{ print_r($field);
} ?>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group label-floating">
                      <label class="control-label">Director</label>
                      <input type="text" class="form-control" name="director" id="director" value="Director Name">
                      <p style="color:red" id="dir"></p>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group image">
                      <label class="control-label">Image</label>
                      <input type="file" name="img" class="form-control" accept="image/*" 
                                                    onChange="document.getElementById('imgsrc').src=window.URL.createObjectURL(this.files[0]);" >
                      <div class="form-group"> <img src="" id="imgsrc" name="" class="img-responsive"  /> </div>
                    </div>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary pull-middle"  id="btnsubmit" onClick="return validate()" title="Submit">Add </button>
                <div class="clearfix"></div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</body>
<script>
  function validate()
{
var title=document.getElementById("title").value;  
var genere=document.getElementById("genere").value;
var duration=document.getElementById("duration").value;  
var director=document.getElementById("director").value;
 
 if(title.length < 3 ||  title.length > 50){$("#tt").html("Invalid Value !!!");document.f1.title.focus() ;return false; }else if(genere==""){$("#gen").html("Enter Category");document.f1.genere.focus() ;return false;  }else if(duration==""){$("#dur").html("Enter duration");document.f1.duration.focus() ;return false; }else if(director==""){$("#dir").html("Enter Director Name");document.f1.director.focus() ;return false; }else { document.getElementById('f1').action="<?php echo site_url()?>/movietime/addnowmovie" ;}}

</script>

<!--   Core JS Files   -->
<script src="<?php echo base_url()?>/assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>/assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>/assets/js/material.min.js" type="text/javascript"></script>
<!--  Charts Plugin -->
<script src="<?php echo base_url()?>/assets/js/chartist.min.js"></script>
<!--  Dynamic Elements plugin -->
<script src="<?php echo base_url()?>/assets/js/arrive.min.js"></script>
<!--  PerfectScrollbar Library -->
<script src="<?php echo base_url()?>/assets/js/perfect-scrollbar.jquery.min.js"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo base_url()?>/assets/js/bootstrap-notify.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Material Dashboard javascript methods -->
<script src="<?php echo base_url()?>/assets/js/material-dashboard.js?v=1.2.0"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo base_url()?>/assets/js/demo.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#multiple-checkboxes').multiselect();
    });
</script>
</html>