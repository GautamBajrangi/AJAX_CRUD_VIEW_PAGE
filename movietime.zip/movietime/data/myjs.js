$(document).ready(function()   {     my_normal_table();    }    );
		function  my_normal_table() {
        $.ajax({
           url:"<?php echo site_url()?>/vC/fdata",
            success: function (data) {
                var mydata = JSON.parse(data);
                // console.log(mydata);   var out;
                var i;
                for (i = 0; i < mydata.length; i++) {  //out += vk.my_id;
					var vk=mydata[i];
                    var htmlok = '<tr id="' + vk.my_id  +'">'
                            + '<td>' +'<input class="delete" id="chk" data-id="'+vk.my_id +'" type="checkbox" name="id[]" value="'+vk.my_id +'"> ' + vk.my_id  +'</td>'
                            + '<td>' + vk.Name + '</td>'
                            + '<td>' + vk.Mobile + '</td>'
							+ '<td>' + vk.Email + '</td>'
							+ '<td>' + vk.DOB + '</td>'
							+ '<td>' + vk.Gender + '</td>'
							+ '<td>' + vk.Course + '</td>'
							+ '<td>' + vk.Hobbies + '</td>'
							+ '<td>' +'<img src="<?php echo base_url()?>data/tryok/'+ vk.User_img +' " style="height:55px;width:55px;">' + /*vk.my_id  +*/ '</td>'
						+ '<td>' 
						+ ' <button type="button" class="btn btn-info btn-sm" onclick="Delete_Ok(' + vk.my_id  +' )"  title="Delete Record Number ' + vk.my_id  +' "><i class="fa fa-trash"></i></button> ' 
						+ ' <button type="button" class="btn btn-success btn-sm" onclick="Edit_Ok(' + vk.my_id  +' )"><i class="fa fa-edit"></i> Edit </button> ' 
						+ ' <button type="button" class="btn btn-danger btn-sm"  onclick="Sweet_Alert(' + vk.my_id  +' )"><i class="fa fa-ban"></i></button>' + '</td>'
                            + '</tr>';

                    $("#show_data").append(htmlok);
				 }
			}
		 });
		}
	
	$('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
      	orientation: "bottom auto",
        todayBtn: false,
        todayHighlight: false,  
    });
	function btn_two()
{  $('#mo_two').modal('show'); } 


////////////////***********************
function Edit_Ok(id)
    {
	  $.ajax({
            type:"get",
            url:"<?php echo site_url()?>/vC/edit_one_data",
            data:{"id_for_edit":id},
            dataType:"json",
            success:function(data){
				$('#form_edit')[0].reset(); 
				var oneRecord=data.oneRow[0];
				 //console.log(data);
               	$('#e_name').val(oneRecord.Name);
                $('#e_email').val(oneRecord.Email);
                $('#e_mob').val(oneRecord.Mobile);
				$('#e_dob').val(oneRecord.DOB);
				$('#e_course').val(oneRecord.Course);
			$("input[id='e_gender'][value='"+oneRecord.Gender+"']").prop('checked', true);
			var vvvv = oneRecord.Hobbies;   cbvalue = vvvv.split(','); 	 
			for(i=0; i < cbvalue.length; i++){  $("input[name='e_hob[]'][value='"+cbvalue[i]+"']").prop('checked', true);	}
			
			$('#e_img').attr('src','<?php echo base_url()?>/data/tryok/'+oneRecord.User_img);
			$('#modal_edit_ok').modal('show');
			$('#hidden_id_for_edit').val(oneRecord.my_id);
			
            }
        });
    } 
	

$(document).ready(function()   {     Get_All_State_Ok();    }    );
		function  Get_All_State_Ok() {
			 $("#state").html( '<option value="" seleced="selected">---Select State---</option>');
			  $("#city").html( '<option value="" seleced="selected">---Select A City---</option>');
			
        $.ajax({
           url:"<?php echo site_url()?>/vC/fetch_state_list",
            success: function (data) {
				 var mydata = JSON.parse(data);  var i;
                for (i = 0; i < mydata.length; i++) {  var vk=mydata[i];
                    var state_tag_html = '<option value="' + vk.id_state  +'">' + vk.state_name  + '</option>';
					 $("#state").append(state_tag_html);
				 }
			}
		 });
		}
		///**********
function Get_City_Value(state_id)
    {
		 $('#city').empty();
	  $.ajax({
            type:"get",
            url:"<?php echo site_url()?>/vC/fetch_city_list_by_state_id",
            data:{"state_id_for_city":state_id},
           success:function(data){
			   $("#city").html('<option selected="selected">---Choose A City---</option>');
			   var mydata = JSON.parse(data);  var k;
                for (k = 0; k < mydata.length; k++) 
								{     var vk=mydata[k];
                 $("#city").append('<option value="' + vk.id_city  +'">' + vk.city_name  + '</option>');
		 						}
		   }
        });
    } 
	  
////************************    Sweet Alert Deleteeeeeeeeeeeeeeeeeeeee
function Sweet_Alert(id)
{
	delId = id;
 swal({
  title: "Are you sure ?",
  text: "You will not be able to recover this record !!",
  type: "warning",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Yes, Delete it !! ",
  cancelButtonText: "No, Cancel it !! ",
  closeOnConfirm: false,
  closeOnCancel: false
},
function(isConfirm) {
            if (isConfirm) {
               swal("Deleted!", "1 record has been deleted.", "success");
               //ajax delete data to database
               $.ajax({
                 url: "<?php echo site_url('/vC/deleteOk'); ?>",
                  type: "get",
				  data:{"id":delId},
                  dataType: "json",
                  success: function(data) {
					   $('#show_data').remove();
					   my_normal_table();  $('#show_data').show(); 
					
					 //$("#show_data").load(window.location + " #show_data");
                    //my_table.draw();
				$("#errdiv").html("<h5>1 Record Deleted successfully</h5>");
                 },
                 });
            } else {
               swal("Cancelled", "Record is safe :)", "error");
            }
         });
      } 
	  ///////////////////////-----------------Model Deleteeeeeeeeeeeeeeeeee
	   function Delete_Ok(id) {
        delId = id;
        $('#DeleteModal').modal('show');  } 
		$('#deletebtn').click(function(){
        $.ajax({
            type:"get",
            url: "<?php echo site_url('/vC/deleteOk_all'); ?>",
            data:{"id":delId},
            dataType:"html",
            success:function(data){
           				   $('#DeleteModal').modal('hide'); 
             		 }
        });
    });  
	function deleteOk(id) {
        delId = id;
        $('#DeleteModal').modal({keyboard: false, backdrop: 'static'});
    }


	/////////////////////////////----------------------------------------------  EDITtttttttttttttttttttt
 
 jQuery(document).ready(function ($) {

   $("#form_edit").submit(function (event) {
                event.preventDefault();
				////*************Validation  
var hob =$("input[id=e_chk]:checked").val();
var Mob= $("input[name=e_mob]").val();		var Name= $("input[name=e_name]").val();  
		 var Em= $("input[id=e_email]").val();
			if(Name.length < "3") { $("#e_Err").html("<marquee>Please Enter a Valid Name</marquee>");  return false }
			 else if(Em.length < "9") {  $("#e_Err").html("<marquee>Please Enter a Valid Email</marquee>");  return false  }
			  else if($("input[id=e_dob]").val()=="") {  $("#e_Err").html("<marquee>Select Birth-Date  </marquee>");  return false }
			   else if(Mob.length!="10") {  $("#e_Err").html("<marquee>InValid Mobile Number !!!</marquee>");  return false }
			   else if($('#e_course').val()=="") {  $("#e_Err").html("<marquee>---Select A Course---</marquee>");   return false} 
				else if(hob==null) { $("#e_Err").html("<marquee>Select A Hobby  (minimum ) !!!</marquee>"); return false} 
			
				////*************Validation
			var formData = new FormData($("#form_edit")[0]);
            console.log(formData);
             
            $.ajax({
                url: "<?php echo site_url('vC/Update_ok')?>",
                type: 'POST',
                data: formData,
				contentType: false,
                processData: false,
                success: function (data) 
                {
				$('#modal_edit_ok').modal('hide'); //my_table.draw();  
				$("#errdiv").html("<h5>1 Record Updated successfully</h5>");
				 },
                error: function(){
               alert("Error in Update To Database"); }
        });
        return false;
    });
 });
 
 function addto()
{	 $('#modal_add_ok').modal('show'); } 


//////////////////****************************  Ajaxxxxxxxx              ADDDD
 jQuery(document).ready(function ($) {
 
   $("#form").submit(function (event) {
                event.preventDefault();
			
	var gen = $("input[name=gender]:checked").val();  var hob =$("input[id=chk]:checked").val();
	
			  //**********   Error Display **********
		 var Mob= $("input[name=mob]").val();		var Name= $("input[name=name]").val();  
		 var Em= $("input[id=email]").val();
			if(Name.length < "3") { $("#ajax_Err").html("<marquee>Please Enter a Valid Name</marquee>");  return false }
			 else if(Em.length < "9") {  $("#ajax_Err").html("<marquee>Please Enter a Valid Email</marquee>");  return false  }
			  else if($("input[id=dob]").val()=="") {  $("#ajax_Err").html("<marquee>Select Birth-Date  </marquee>");  return false }
			   else if(Mob.length!="10") {  $("#ajax_Err").html("<marquee>InValid Mobile Number !!!</marquee>");  return false }
			   else if(gen==null) { $("#ajax_Err").html("<marquee>Select Gender !!!</marquee>"); return false} 
			    else if($('#course').val()=="") {  $("#ajax_Err").html("<marquee>---Select A Course---</marquee>");   return false} 
				else if(hob==null) { $("#ajax_Err").html("<marquee>Select A Hobby  (minimum ) !!!</marquee>"); return false} 
				else if($('#state').val()=="") { $("#ajax_Err").html("<marquee>---Select A State---</marquee>"); return false} 
				else if($('#city').val()=="") { $("#ajax_Err").html("<marquee>---Select A City From List---</marquee>"); return false} 
				else if($('#User_img').val()=="") { $("#ajax_Err").html("<marquee>---Upload One Image---</marquee>"); return false} 
			
				//**********   Error Display **********
            var formData = new FormData($("#form")[0]);
            //console.log(formData);
             
            	$.ajax({
                url: "<?php echo site_url('vC/ajax_add')?>",
                type: 'POST',
                data: formData,
				contentType: false,
                processData: false,
                success: function (data) 
                {  		$('#mo_two').modal('hide'); //my_table.draw();
						$("#errdiv").html("<h5>1 Record Inserted successfully</h5>");
						$('#form')[0].reset(); 
				},
				 //setTimeout(function () {  $("#errdiv").hide();  }, 5000);
				error: function(){  alert("Error in Form submission"); }
        });
        return false;
    });
 });
 //////////////*****************
 function selectAll(source) {
            checkboxes = document.getElementsByName('id[]');
            for (var i = 0, n = checkboxes.length; i < n; i++) {
                checkboxes[i].checked = source.checked;
            }
        }
 ///////*********************  bulk Deleteeeeeeeeeeeeeeeeeeee
 function getForDeleteValue()
{
var checked_id_Array = [];
	
	$(".delete:checked").each(function() {
		checked_id_Array.push($(this).val());
	}); 	if(checked_id_Array.length < 1){ alert("You've not selected any thing to delete  !!! ");	return false  }
	
	
	swal({
  title: "Are you sure ?",
  text: "You will not be able to recover this record !!",
  type: "warning",
  showCancelButton: true,
   
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Yes, Delete it !! ",
  cancelButtonText: "No, Cancel it !! ",
  closeOnConfirm: false,
  closeOnCancel: false
},
function(isConfirm) {
            if (isConfirm) {
               swal("Deleted!", "1 record has been deleted.", "success");
               //ajax delete data to database
			   
               $.ajax({
				    type:"get",
                      url: "<?php echo site_url('/vC/deleteOk_all22'); ?>",
                 
				    data:{"id_for_delete_all":checked_id_Array},
           		 dataType:"html",
               
                  success: function(data) {
                    my_table.draw();
			$("#errdiv").html("<h5>Record(s) Deleted successfully</h5>");
                 },
                 });
            } else {
				
               swal("Cancelled", "Record is Safe :)", "error");
            }
         });
      }  
	/////////*********************
