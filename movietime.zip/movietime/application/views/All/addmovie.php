<title>Movie Time</title>
<h1 align="center">Hello welcome to MovieBook.com</h1>
<br>
<br>


<h4 align="center">add Show</h4> 
<table align="center" border="2" >

	<form name="f1" id="f1" enctype="multipart/form-data" method="post" action="<?php echo site_url()?>/movietime/addnowmovie">


<tr>
<td>Title</td>
<td><input type="text" name="title" id="title" required></td>
</tr>

<tr>
<td>Genere ( Category )</td>
<td><input type="text" name="genere" id="genere" required></td>
</tr>

<tr>
<td>Duration</td>
<td><input type="number" name="duration" min="20" max="200" required></td>
</tr>

<tr>
<td>Director</td>
<td><input type="text" name="director"  required></td>
</tr>

<tr>
<td>Image</td>
<td><input type="file" name="img" ></td>
</tr>
	
<td colspan="2" align="center"><button type="submit" id="sub"  >Add Now 
</button></td>



</form>

</table>