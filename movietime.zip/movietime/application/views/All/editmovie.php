
<title>Movie Time</title>
<h1 align="center">Hello welcome to MovieBook.com</h1>
<br>
<br>


<h4 align="center">Edit Movie</h4> 
<table align="center" border="2" >

	<form name="f1" id="f1" enctype="multipart/form-data" method="post" action="<?php echo site_url()?>/movietime/updatemovie/<?php echo $one->id ?>" />
	<input type="hidden" name="idd" value="<?php echo $one->id ?>"  />

<tr>
<td>Title</td>
<td><input type="text" name="title" id="title" value="<?php echo $one->title ?>" required></td>
</tr>

<tr>
<td>Genere ( Category )</td>
<td><input type="text" name="genere" id="genere" value="<?php echo $one->genere ?>" required></td>
</tr>

<tr>
<td>Duration</td>
<td><input type="number" name="duration" min="20" max="200" value="<?php echo $one->duration ?>" required></td>
</tr>

<tr>
<td>Director</td>
<td><input type="text" name="director" value="<?php echo $one->director ?>" required></td>
</tr>

<tr>
<td>Image</td>
<td><input type="file" name="img" >
<br>
<?php echo $one->image ?></td>
</tr>
	
<td colspan="2" align="center"><button type="submit" id="sub"  >Update Now 
</button></td>



</form>

</table>