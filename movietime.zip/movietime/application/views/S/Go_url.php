

<a href="<?php echo $vv->long_url?>">Go</a>