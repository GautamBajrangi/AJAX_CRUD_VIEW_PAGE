<title>Movie Time</title>
<h1 align="center">Hello welcome <?php echo $this->session->userdata('em');?> to MovieBook.com</h1>
<br>
<br>


<h4 align="center">Admin Side </h4> 


<a href="<?php echo site_url()?>/movietime/addmovie">Add Movie</a>  ||| <a href="<?php echo site_url()?>/movietime/addshow">Add show</a>

<br><br><br><br><br><br><br><br><br><br>
<form name="f2" id="f2" method="post" enctype="multipart/form-data" action="<?php echo site_url()?>/movietime/logout">
	
<td colspan="2" align="right"><button type="submit" id="sub"  >Log Out
</button></td>
</form>





<h4 align="center">movie table </h4> 
<table align="center" border="2" >
	<tr>
<th >id</th>
<th>title</th>
<th>director</th>
<th>genere</th>
<th>duration</th>
<th>img</th>
<th colspan="2">Action</th></tr>

<?php foreach($alldata as $a) { ?>
<tr>
<td><?php echo $a->id ?></td>
<td><?php echo $a->title ?></td>
<td><?php echo $a->director ?></td>
<td><?php echo $a->genere ?></td>
<td><?php echo $a->duration ?></td>
<td ><?php echo $a->image ?>  </td>
<td><img src="<?php echo base_url()?>./data/<?php echo $a->image?>" height="50" width="50" alt="<?php echo $a->id ?>">
</td>

<td><a href="<?php echo site_url()?>/movietime/delete/<?php echo $a->id?>">Delete  </a> |||| <a href="<?php echo site_url()?>/movietime/editmovie/<?php echo $a->id?>">Edit </a></td>

</tr>

<?php } ?>
</table>













<h4 align="center">shows table </h4> 
<table align="center" border="2" >
	<tr>
<th>id</th>
<th>MId</th>
<th>screen</th>
<th>slot</th>
<th>booked</th>

<th colspan="2">Action</th></tr>

<?php foreach($alldatav as $a) { ?>
<tr>
<td><?php echo $a->id ?></td>
<td><?php echo $a->MId ?> || <?php echo $a->title ?></td>
<td><?php echo $a->screen ?></td>
<td><?php echo $a->slot ?></td>
<td><?php echo $a->booked ?></td>

<td><a href="<?php echo site_url()?>/movietime/delete/<?php echo $a->id?>">Delete  </a> ||||

<a href="<?php echo site_url()?>/movietime/edit/<?php echo $a->id?>">Edit  </a></td>

</tr>

<?php } ?>
</table>