<?php $ee = substr($yes->long_url, 0, 4);?>
<html>
<head>
<title><?php echo $yes->long_url?></title>
</head>
<body>
<h4>Hello, Please wait ......  You're Redirecting to <strong style="color:#C03"><?php echo $yes->long_url ?></strong> in a moment !!!! </h4>
</body>
</html>
<script>

window.onload=function(){ setTimeout(gotourl,1500)};
function gotourl()
{ window.open("<?php if(ucwords($ee)=="Www."){?>https://<?php }?><?php echo $yes->long_url ; ?>","_top");}

</script>