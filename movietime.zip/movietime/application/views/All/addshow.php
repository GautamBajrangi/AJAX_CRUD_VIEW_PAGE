<title>Movie Time</title>
<h1 align="center">Hello welcome to MovieBook.com</h1>
<br>
<br>


<h4 align="center">Add show </h4> 
<table align="center" border="2" >

	<form name="f1" id="f1" enctype="multipart/form-data" method="post" action="<?php echo site_url()?>/movietime/addnowshow">


<tr>
<td>Screen</td>
<td><input type="number" name="screen" min="1" max="200"  required></td>
</tr>


<tr>
<td>Slot</td>
<td><input type="number" name="slot" min="1" max="200"  required></td>
</tr>

<tr>
<td>Mid</td>
<td>
	<select name="mid">
		<?php foreach($sb as $s) { ?>
		<option value="<?php echo $s->id ?>"><?php echo $s->title ?> 

		</option>
		<?php } ?>
		

	</select>

</td>
</tr>

<tr>
<td>Booked</td>
<td><input type="number" name="booked" min="1" max="2000" required></td>
</tr>


	
<td colspan="2" align="center"><button type="submit" id="sub"  >Add Now 
</button></td>



</form>

</table>