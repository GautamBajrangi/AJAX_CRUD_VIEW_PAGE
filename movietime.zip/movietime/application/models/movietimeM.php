<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class movietimeM extends CI_Model {

	public function __construct()
	{ parent:: __construct();

		$this->load->model('movietimeM');
		date_default_timezone_set('asia/kolkata');
	}
	
	function save_ajax(){
		$data = array(
				'Name' 	=> $this->input->post('name'), 
				'Email' 	=> $this->input->post('email'), 
				'Mobile' => $this->input->post('mob'), 
					'DOB' => $this->input->post('dob'),
					'Gender' => $this->input->post('gender'),
					'Course' => $this->input->post('course'), 
			);
		$result=$this->db->insert('register',$data);
		return $result;
	}
	 function Update_batch($tbl, $data, $con) {
        $this->db->update_batch($tbl, $data, $con);
        return $this->db->affected_rows();
    }
	
	/* function ajax_add()  {	extract($_REQUEST);
	 $config['upload_path']='./data/tryok/';$config['allowed_types']='gif|jpg|png|bmp|jpeg';$config['max_size']='1500';$config['max_width']='1000';
	 $config['max_height']='1000'; $config['encrypt_name']=true; $this->load->library('upload',$config);
	 if(!$this->upload->do_upload('User_img')) {$file['imgerr']=$this->upload->display_errors();	print_r($file['imgerr']);	}
		else	{  $img_ok=array('upload_data'=>$this->upload->data());   
	$data = array('Name' => $name,'Email' => $email,'DOB' => $dob,'Mobile' => $mob,'Hobbies' => implode(',',$hob),  
				 'Course' => $course, 'User_img'=>$img_ok['upload_data']['file_name']   ); $this->movietimeM->save($data); }}*/


	
	public function reg()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$password=$this->input->post('password');
		$country=$this->input->post('country');
		$zip=$this->input->post('zip');

		$this->db->where('email',$email);
		$users=$this->db->get('users')->row();
		if(count($users)>0)
			{  echo "exists !!!";}

		else {
		$ins = array("name" =>$name ,"email" =>$email ,"password" =>$password ,"country" =>$country  );
		$this->db->insert('users',$ins);

		redirect('movietime'); }

	}
	
	public function save($data)
	{
		$this->db->insert('register', $data);
		return $this->db->insert_id();
	}
	public function insert_one($tablename,$data)
	{
		$this->db->insert($tablename, $data);
	}
	
function Update_data($tbl, $con, $data) {
        $this->db->where($con);
        $this->db->update($tbl, $data);
        return $this->db->affected_rows();
    }

	public function logincheck()
	{
		
		$email=$this->input->post('emailv');
		$password=$this->input->post('pass');

		$this->db->where('email',$email);$this->db->where('password',$password);
		$users=$this->db->get('users')->row();
		if(count($users)> 0)
			{ 
				$this->session->set_userdata('em',$email);
				$this->session->set_userdata('ps',$password);
			redirect('movietime/homeadm');
		}

		else {  echo "invalid email or password !!!";}
		}



	public function addnowmovie()
	{
		$title=$this->input->post('title');
		  $genere=$this->input->post('genere');
		$duration=$this->input->post('duration');
		$director=$this->input->post('director');

		
			$config['upload_path']='./data/';
			$config['allowed_types']='gif|jpg|png|bmp|jpeg';
			$config['max_size']='5000';
			$config['max_width']='5000';
			$config['max_height']='5000';
			$config['encrypt_name']=true;
			$this->load->library('upload',$config);
		
		if(!$this->upload->do_upload('img'))
		{
			$file['imgerr']=$this->upload->display_errors();	
			print_r($file['imgerr']);
		}
		else
			{
			$data=array('upload_data'=>$this->upload->data());
			
			$ins=array
			(
			"title"=>$title,
			"director"=>$director,"duration"=>$duration,"genere"=>$genere,
			"image"=>$data['upload_data']['file_name']
			);
			
			$this->db->insert('moviedatabase',$ins);

			//print_r($ins);die();
			redirect('movietime/homeadm');
			
			}
		}


public function addnowshow()
	{
		$mid=$this->input->post('mid');
		$slot=$this->input->post('slot');
		$screen=$this->input->post('screen');
		$booked=$this->input->post('booked');
		
		$ins = array("MId" =>$mid ,"slot" =>$slot ,"screen" =>$screen ,"booked" =>$booked  );
		$this->db->insert('shows',$ins);

		redirect('movietime/homeadm');

	}

		public function delete($id)
		{
			$this->db->where('id',$id);
			$idok=$this->db->get('moviedatabase')->row();
			$image=$idok->image;
			$path="data/";
			
			$dir=opendir($path);
			while($file=readdir($dir))
			{
				if($file==$image)
				{
				 	unlink($path.$image);
				}
				$this->db->where('id',$id);
				$this->db->delete('moviedatabase');
			}	
			redirect('movietime/homeadm');
		}
		public function deleteShow($id)
		{
			$this->db->where('id',$id);
			$this->db->delete('shows');
			redirect('movietime/homeadm');
		}
		
	public function updatemovie($id)
	{
		$imgfile="";
		$idd=$this->input->post('idd');
		$title=$this->input->post('title');
		$genere=$this->input->post('genere');
		$duration=$this->input->post('duration');
		$director=$this->input->post('director');

			$config['upload_path']='./data/';
			$config['allowed_types']='gif|jpg|png|bmp|jpeg';
			$config['max_size']='5000';
			$config['max_width']='5000';
			$config['max_height']='5000';
			$config['encrypt_name']=true;
			
			$this->load->library('upload',$config);	
			
			if(!$this->upload->do_upload('img'))
		{
			$file['imgerr']=$this->upload->display_errors();
			//print_r($file['imgerr']);
			if($file['imgerr']=="You did not select a file to upload.")
			{ $update=array(	
						"title"=>$title,
			"director"=>$director,"duration"=>$duration,"genere"=>$genere,
						
						);
			
				$this->db->where('id',$idd);
				$this->db->update('moviedatabase',$update); }
				if($file['imgerr']!="You did not select a file to upload.")
				{ print_r($file['imgerr']); }
				
		}
		else
		{
			/*	$this->db->where('id',$idd);
				$idfor=$this->db->get('moviedatabase')->row();
				$image=$idfor->image;
				$path="./data/";
				$dir=opendir($path);
				
				while($file=readdir($dir))
				{
					if($file==$image)
					{
						unlink($path.$image);
					}
				}*/
			$data=array('upload_data'=>$this->upload->data() );
			
				$update=array(	
						"title"=>$title,
			"director"=>$director,"duration"=>$duration,"genere"=>$genere,
						"image"=>$data['upload_data']['file_name']
						);
			
				$this->db->where('id',$idd);
				$this->db->update('moviedatabase',$update);
		}
					redirect('movietime/homeadm');
		
		}
		//******************************
		
		
		public function Generate_custom_url()
	{
		$str = "";	 $letnum = array_merge(range('A','Z'), range('a','z'), range('0','9') , array('-','_'));  $max = count($letnum) - 1;
		for ($i = 0; $i < 5; $i++) {  $c10 = mt_rand(0, $max); $str .= $letnum[$c10]; 	}
		$any=$str;     
     	$str1 = "";  $letnum1 = array_merge(range('A','Z'),  range('0','9') ,range('a','z'), array('-','_')); 	$max1 = count($letnum1) - 1;
		for ($i = 0; $i < 9; $i++) {  $c101 = mt_rand(0, $max1); $str1.= $letnum1[$c101]; 	}
		$any1=$str1;  $auto_url=$any1;  
		//print_r($auto_url); die();  
		
		$long_url=$this->input->post('long_url');
		$small = substr($tt->long_url, 0, 4); echo ucwords($small);
		//if(ucwords($long_url)=="Www.") { }  
		
		
		$chk=$this->input->post('chk');
		$custom_url=$this->input->post('custom_url');
		$curdate=date('Y-m-d H:i:s');
		
		if($chk!="" && $custom_url=="") {echo "Custom URL can not be Empty !!";  }
		
		
		if($custom_url=="" && $chk=="") { $auto_url ;
		$this->db->where('auto_url',$auto_url);
		$vv=$this->db->get('tinyurl')->row();
		if(count($vv)>0) {  $create = array("long_url" =>$long_url ,"auto_url" =>$auto_url.$any ,"dr" =>$curdate ,  );
		$this->db->insert('tinyurl',$create); $getone=$this->db->get('tinyurl')->row();
		
		$this->session->set_tempdata('YOUR_URL',$getone->long_url,10);
		$this->session->set_tempdata('tiny',$getone->auto_url,10);
		redirect('toC/Add_url_page'); }

		else {
		$create = array("long_url" =>$long_url ,"auto_url" =>$auto_url ,"dr" =>$curdate ,  );
		$this->db->insert('tinyurl',$create);
		$this->db->where('auto_url',$auto_url);
		$getone=$this->db->get('tinyurl')->row();
		
		$this->session->set_tempdata('YOUR_URL',$getone->long_url,10);
		$this->session->set_tempdata('tiny',$getone->auto_url,10);
		redirect('toC/Add_url_page'); 
		} }
		
		
		else if($custom_url!="" && $chk=="") { 
		$this->db->where('custom_url',$custom_url);
		$vv=$this->db->get('tinyurl')->row();
		if(count($vv)>0) {  echo "This is Already Taken !!!";}

		else {
		$create = array("long_url" =>$long_url ,"custom_url" =>$custom_url ,"dr" =>$curdate , );
		$this->db->insert('tinyurl',$create);
		$this->db->where('custom_url',$custom_url);
		$getone=$this->db->get('tinyurl')->row();
		
		$this->session->set_tempdata('YOUR_URL',$getone->long_url,10);
		$this->session->set_tempdata('tiny',$getone->custom_url,10);
		
		redirect('toC/Add_url_page'); } }
		
		else if($chk!="" && $custom_url!="") { 
		$this->db->where('custom_url',$custom_url);
		$this->db->or_where('auto_url',$auto_url);
		$vv=$this->db->get('tinyurl')->row();
		if(count($vv)>0) {  echo "This is Already Taken !!!";}

		else {
		$create = array("long_url" =>$long_url ,"custom_url" =>$custom_url ,"dr" =>$curdate , "auto_url" =>$auto_url , );
		$this->db->insert('tinyurl',$create);
		$this->db->where('custom_url',$custom_url);
		$getone=$this->db->get('tinyurl')->row();
		
		$this->session->set_tempdata('YOUR_URL',$getone->long_url,10);
		$this->session->set_tempdata('tiny',$getone->custom_url,10);
		
		redirect('toC/Add_url_page'); } }
		

	}
	
	public function add_slider_ok()
		{
		
			$slider_title=$this->input->post('title');
			$slider_des=$this->input->post('about');
			
			$config['upload_path']='./data/Slider/';
			$config['allowed_types']='jpg|jpeg';
			$config['encrypt_name']=true;
			$this->load->library('upload',$config);
		
		if(!$this->upload->do_upload('img'))
		{
			$file['imgerr']=$this->upload->display_errors();	
			echo $file['imgerr'];
		}
		else
			{
			$data=array('upload_data'=>$this->upload->data());
			
			$inst=array
				(
			"slider_name"=>$slider_title,
			"slider_des"=>$slider_des,
			"slider_img"=>$data['upload_data']['file_name']
				);
			$this->db->insert('slider',$inst);
			
	redirect('toC/add_slider');
		}
	}
	public function add_p_ok()
		{
			$config['upload_path']='./data/Product/';
			$config['allowed_types']='jpg|jpeg';
			$config['encrypt_name']=true;
			$this->load->library('upload',$config);
		
		if(!$this->upload->do_upload('img'))
		{ $file['imgerr']=$this->upload->display_errors();	print_r($file['imgerr']); die(); }
		else
			{
			$data=array('upload_data'=>$this->upload->data());
			$inst=array("p_name"=>$this->input->post('title'),"p_des"=>$this->input->post('about'),"p_img"=>$data['upload_data']['file_name']);
			$this->db->insert('product',$inst);
			redirect('toC/add_p');
		}
	}
		/////////////*********************
		
	public function Custom_query($str) {
        $query = $this->db->query($str);		
        return $query->result_array();
    }
	
	/*  Delete Duplicate Records by Coulmn name
	
delete from Table_Name  where pincode_id not in
( select min_id from (select min(pincode_id) as min_id from Table_Name group by pincode_pin,pincode_city,pincode_state) as newtable) 
	

	*/
	
	





















}?>