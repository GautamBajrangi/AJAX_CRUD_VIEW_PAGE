<html>
<head>
<title>DataTable</title>
<!-- Latest compiled and minified CSS /c1o52lqlbd7s -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/Loader/loader.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css"  >
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/jquery.dataTables.min.css">
<!--link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-treegrid/0.2.0/css/jquery.treegrid.css"-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.transitions.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.transitions.min.css">
<!--link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-treegrid/0.2.0/css/jquery.treegrid.css"-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/easy-autocomplete/1.3.5/easy-autocomplete.themes.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/easy-autocomplete/1.3.5/easy-autocomplete.min.css">
<style>
#owl-demo .item img {
	display: block;
	width: 100%;
	height: auto;
}
</style>
</head>
<body>

<div id="owl-demo" class="owl-carousel owl-theme">
  <?php foreach($Slider as $s) { ?>
  <div class="item"><img src="<?php echo base_url()?>data/Slider/<?php echo $s->slider_img ?>" alt="<?php  $s->slider_img ?>" ></div>
  <?php } ?>
</div>
<br>
<br>
<table>
  <div class="form-group  col-sm-3">
    <input type="text" class="form-control" name="srch" id="srch" placeholder="search " data-toggle="popover" title="Imp Notice" data-content="Please Not That it's only data toggle to show to users !!!">
    &nbsp; &nbsp; <p><?php echo get_cookie('w1')."<br>";
		echo get_cookie('w2')."<br>";
		echo get_cookie('w3')."<br>";  ?></p>
    <p class="loader" align="center"></p>  &nbsp; <?php echo $this->benchmark->memory_usage();?>
  </div>
</table>
<button type="button" class="btn btn-danger" data-toggle="popover" data-content="Please Not That it's only data toggle to show to users !!!">Click to toggle popover</button>

<table id="example" class="display" style="width:100%">

  <thead>
    <tr id="">
      <th>###</th>
      <th>First name</th>
      <th>Last name</th>
      <th>Position</th>
      <th>Office</th>
      <th> Date Joining</th>
      <th>IMG</th>
      <th >Action</th>
      </tr>
  </thead>
  <tbody>
  </tbody>
</table>

<!---    Delete Model !!! Start    -->
<div class="modal fade" id="DeleteModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog ">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> &times; </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h4>
              <center>
                Do You Want to Delete This Record ??
              </center>
            </h4>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" id="deletebtn"   class="btn btn-danger">Yes Delete</button>
        <button type="button" class="btn btn-primary" data-dismiss="modal">No !!</button>
      </div>
    </div>
  </div>
</div>
<!---    Delete Model !!! Enddd    -->

</body>
</html>
<script src="https://code.jquery.com/jquery-3.3.1.js"  type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"  type="text/javascript"></script>
<!--script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-treegrid/0.2.0/js/jquery.treegrid.js"  type="text/javascript"></script-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
<script type="text/javascript" >
$(document).ready(function() {
    $('#example').DataTable( {
      		processing: true,
            serverSide: true,
		"lengthMenu": [[8, 16, 24,48,96,168,555], [8, 16, 24,48,96,168,555]],
        "pageLength": 8,
            ajax:"<?php echo site_url()?>/toC/fetch_all",
            'aoColumnDefs': [{
                						'bSortable': false,
               							'aTargets': [-2,-1,-3]  
								    }]
		 } );
} );

function openmo(id)
{  deleteid = id;
$('#DeleteModal').modal('show');}
   $('#deletebtn').click(function(){
                                    $.ajax({
                                        type:"get",
                                        url:"<?php echo site_url() ?>/toC/deleteRecord/",
                                        data:{"id":deleteid},
                                        dataType:"html",
              success:function(data)   {   
			  $('#DeleteModal').modal('hide'); 
			      
				 location.reload();    
				  
				   }
			  });
              });
			  
 function modal_edit(id)
{  editid = id;
$('#modal_edit_ok').modal('show');}


</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/easy-autocomplete/1.3.5/jquery.easy-autocomplete.min.js"></script>
<script type="text/javascript" >
 $(document).ready(function() {
  $("#owl-demo").owlCarousel({
   navigation : true, // Show next and prev buttons
   slideSpeed : 1000,
      autoPlay : 3000,
    stopOnHover : true,
     paginationSpeed : 600,
	  navigation:true,
 transitionStyle : "goDown",
	  autoHeight : true,
   singleItem:true
     
          // "singleItem:true" is a shortcut for:
          // items : 1, 
          // itemsDesktop : false,
          // itemsDesktopSmall : false,
          // itemsTablet: false,
          // itemsMobile : false
      });
    });
</script>
<script type="text/javascript" >
 $(document).ready(function() {
     
      $("#owl-demo_p").owlCarousel({
        items : 7,
        lazyLoad : true,
		 autoPlay : 1921,
    stopOnHover : true,
		navigation : true
      }); 
     
    });

</script>
<br>
<br>
<style>
#owl-demo_p .item {
	margin:3px;
}
#owl-demo_p .item img {
	display:block;
	width:100%;
	height:auto;
}
</style>
<div id="owl-demo_p" class="owl-carousel ">
<?php foreach($Pro as $p) { ?>
<div class="item"><?php  $p->p_name ?>
<a href="<?php echo site_url()?>/toC/pview/<?php echo $p->id ?>" ><img data-src="<?php echo base_url()?>data/Product/<?php echo $p->p_img ?>" alt="<?php  $p->p_img ?>"  class="lazyOwl" ></a>
</div><?php } ?></div>
<script>
$(document).ready(function(){
var options = {
  url: "<?php echo site_url() ?>/toC/autocomplete",
getValue:"firstname", 
list: {match: {enabled: true }},
    template: {
    type: "custom",
    method: function(value,item) {
		if(value.length>15)
		{value=value.substr(0,25);}
     return "<b><span style='width:40px;height:40px;'>"+" <span >"+value+"</span></span></b>";
	}
  },
 theme: "plate-dark"
};
$("#srch").easyAutocomplete(options);
});
</script>
<div class="modal fade" id="modal_edit_ok" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
      <form action="<?php echo base_url('toC/Update_to') ?>" method="post">
        <div class="modal-body">
          <div class="row">
            <input type="hidden" id="hidv1" name="hidv1">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mod-data">
              <section class="panel panel-border">
                
                <div class="panel-body">
                      <div class="form-group ">
                       First Name<input type="text" name="fn" value="" id="fn" class="form-control ff" >
                      </div>
                      <div class="form-group">
                        Last Name<input type="text" name="ln" value="" id="ln" class="form-control ff">
                      </div>
                      <div class="form-group">
                    Position<input type="text" name="po" value="" id="po" class="form-control ff" >
                      </div>
                      <div class="form-group">
                      Office<input type="text" name="of" value="" id="of" class="form-control ff" >
                      </div>
                  
                </div>
              </section>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button data-dismiss="modal" class="btn btn-default"type="button">Close</button>
          <button class="btn btn-success" type="submit" name="submit" >Save changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!------>
<script type="text/javascript" >$(function () {  $('[data-toggle="popover"]').popover() }) </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.bundle.js"></script>





