-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2018 at 09:47 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movietime`
--

-- --------------------------------------------------------

--
-- Table structure for table `area_list`
--

CREATE TABLE `area_list` (
  `id_area` int(6) NOT NULL,
  `area_name` varchar(25) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `dr` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `st` varchar(1) NOT NULL DEFAULT 'A',
  `city_fk` int(5) NOT NULL,
  `state_fk` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area_list`
--

INSERT INTO `area_list` (`id_area`, `area_name`, `pincode`, `dr`, `st`, `city_fk`, `state_fk`) VALUES
(1, 'Dindoli', '394210', '2018-07-17 16:28:36', 'A', 3, 1),
(2, 'Kim', '394110', '2018-07-17 17:56:56', 'A', 3, 1),
(3, 'Mota Varachha', '394101', '2018-07-17 17:59:13', 'A', 3, 1),
(4, 'Piplod', '394370', '2018-07-17 18:00:03', 'A', 3, 1),
(5, 'Sama', '390008', '2018-07-17 18:01:36', 'A', 4, 1),
(6, 'Vadia', '391520', '2018-07-17 18:02:09', 'A', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `city_list`
--

CREATE TABLE `city_list` (
  `id_city` int(6) NOT NULL,
  `city_name` varchar(25) NOT NULL,
  `st` varchar(1) NOT NULL DEFAULT 'A',
  `dr` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state_fk` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city_list`
--

INSERT INTO `city_list` (`id_city`, `city_name`, `st`, `dr`, `state_fk`) VALUES
(3, 'Surat', 'A', '2018-07-17 12:38:34', 1),
(4, 'Vadodara', 'A', '2018-07-17 12:39:23', 1),
(5, 'Navasari', 'A', '2018-07-17 12:39:23', 1),
(6, 'Jodhpur', 'A', '2018-07-17 12:40:28', 3),
(11, 'Jaipur', 'A', '2018-07-17 12:41:41', 3),
(12, 'Ajmer', 'A', '2018-07-17 12:41:53', 3),
(13, 'Varanasi', 'A', '2018-07-17 12:42:29', 2),
(14, 'Kanpur', 'A', '2018-07-17 12:42:36', 2),
(15, 'Agra', 'A', '2018-07-17 12:42:55', 2),
(16, 'Chennai', 'A', '2018-07-17 12:43:16', 4),
(17, 'Madhurai', 'A', '2018-07-17 12:43:36', 4),
(18, 'Karur', 'A', '2018-07-17 12:43:56', 4),
(19, 'Bhopal', 'A', '2018-07-17 16:05:40', 5),
(21, 'Gwalior', 'A', '2018-07-17 16:06:11', 5),
(22, 'Ujjain', 'A', '2018-07-17 16:06:33', 5),
(23, 'Indore', 'A', '2018-07-17 16:06:41', 5);

-- --------------------------------------------------------

--
-- Table structure for table `ctemp`
--

CREATE TABLE `ctemp` (
  `id` int(8) NOT NULL,
  `pid` int(8) NOT NULL,
  `uid` varchar(66) NOT NULL,
  `dr` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `qty` int(2) NOT NULL DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ctemp`
--

INSERT INTO `ctemp` (`id`, `pid`, `uid`, `dr`, `qty`) VALUES
(1, 28, 'jp16t9spskflatp3uwwkjt', '2018-06-27 14:40:56', 2),
(2, 28, 'y5wlsmnza2qpz0yubyoj93', '2018-06-27 14:41:40', 2),
(3, 28, '9x2ddlxg0qdvus4u81fmf5', '2018-06-27 14:41:49', 2),
(4, 35, 'q27suy1y93om7kxvyr8x9n', '2018-06-27 14:41:56', 2),
(5, 28, 'lmtavunq0ozjnrz6am2vxb', '2018-06-27 14:42:07', 2),
(6, 29, '2s4g01rcalgsy4sc5yrc67', '2018-06-27 14:42:20', 2),
(7, 28, 'o9rwh0benyz3248kmt03vk', '2018-06-27 14:42:32', 2),
(8, 34, 'q5w6bvedgyqqxkdphsbnk5', '2018-06-30 11:24:38', 2),
(9, 24, 'hhwhyo8z0a47oujfwzdvda', '2018-06-30 11:27:01', 2);

-- --------------------------------------------------------

--
-- Table structure for table `moviedatabase`
--

CREATE TABLE `moviedatabase` (
  `id` int(11) NOT NULL,
  `title` varchar(80) DEFAULT NULL,
  `genere` varchar(20) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `director` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `moviedatabase`
--

INSERT INTO `moviedatabase` (`id`, `title`, `genere`, `duration`, `director`, `image`) VALUES
(90, 'Type Any Title', 'Type Any Category', 108, 'Director Name', '75dc3c95327aa6d375964a5eb1ede8dd.jpg'),
(92, 'aaaaqqq', 'aa', 108, 'sss', '5fe77752691c1306339a81c5e1e54171.jpg'),
(93, 'qwesssdf', 'gasfgfg', 108, 'gafgf', '488727c09a9d39d5c6af7734af1bf10f.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_img` varchar(50) NOT NULL,
  `p_des` varchar(100) NOT NULL,
  `dr` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `st` enum('Y','N') NOT NULL DEFAULT 'Y',
  `views` int(8) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `p_name`, `p_img`, `p_des`, `dr`, `st`, `views`) VALUES
(23, 'aa', '154986271072008cafd80b42ee6f32f0.jpg', 'aa', '2018-06-23 12:11:38', 'Y', 0),
(24, 'p2', '2725af3080de84df13330400f41c1196.jpg', 'p2', '2018-06-26 14:25:02', 'Y', 0),
(25, 'p3', '85045d0119b90351b008cdb8ee2c7ce1.jpg', 'p3', '2018-06-26 14:25:11', 'Y', 0),
(26, 'dfwf', '2eb1bcb59375f964519c333f6795b480.jpg', 'rwgrgr', '2018-06-27 11:27:57', 'Y', 0),
(27, 'hstgh', '243a382de9d86e40b07207c0a9f0dcaf.jpg', 'ghghg', '2018-06-27 11:28:24', 'Y', 0),
(28, 'hss', 'a3bea56473d32b10d019e5722948009a.jpg', 'hshrry', '2018-06-27 11:28:33', 'Y', 0),
(29, 'trtyt', '3dec941cb20c041dcf37fc983bce7a17.jpg', 'sffgh', '2018-06-27 11:28:40', 'Y', 0),
(30, 'kii', 'e644eecc1d510d74dd18fb38fed7049f.jpg', 'louilu', '2018-06-27 11:28:49', 'Y', 0),
(31, 'tyudtyu', 'e1fbac5b98473506e45994ca27468639.jpg', 'dyuyu', '2018-06-27 11:29:02', 'Y', 0),
(32, 'fjkgjk', '683844f62453822511700ac0929c5b01.jpg', 'kgjk', '2018-06-27 11:29:15', 'Y', 0),
(33, 'kfj', '6489c182171f6764899fed3373b48fac.jpg', 'jkj', '2018-06-27 11:29:32', 'Y', 0),
(34, 'gf', '694c521fa8a0185e93de5c9750069875.jpg', 'fghdfsh', '2018-06-27 11:30:22', 'Y', 0),
(35, 'hdsh', '2ca9b3d4945c084c564544679c8f86a5.jpg', 'dhdh', '2018-06-27 11:30:31', 'Y', 0),
(36, 'hghgfh', 'fa1a7480cb1693577ed0bcfc80849f2a.jpg', 'gfdhgh', '2018-06-27 11:30:39', 'Y', 0),
(37, 'hgfh', '654a1b1671d68041e16374ff4aad1b9c.jpg', 'hgfh', '2018-06-27 11:31:00', 'Y', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `my_id` int(8) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Mobile` varchar(15) NOT NULL,
  `Email` varchar(55) NOT NULL,
  `DOB` date NOT NULL,
  `Gender` varchar(1) NOT NULL DEFAULT 'M',
  `Course` varchar(20) NOT NULL,
  `Hobbies` varchar(55) NOT NULL,
  `User_img` varchar(50) NOT NULL,
  `Profile` varchar(55) NOT NULL,
  `User_dr` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `User_st` varchar(1) NOT NULL DEFAULT 'A',
  `State_fk` int(5) NOT NULL DEFAULT '1',
  `City_fk` int(5) NOT NULL DEFAULT '3',
  `Area_fk` int(5) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`my_id`, `Name`, `Mobile`, `Email`, `DOB`, `Gender`, `Course`, `Hobbies`, `User_img`, `Profile`, `User_dr`, `User_st`, `State_fk`, `City_fk`, `Area_fk`) VALUES
(57, 'Gautam Bajrangi', '5365541111', 'gautam@yes.in', '2018-07-02', 'F', 'BCA', 'Music,Sports', 'a825fba8726a1de2c537634d0a4e39cb.jpg', '', '2018-07-09 11:38:50', 'D', 1, 3, 1),
(61, 'Rishabh', '9797252525', 'rishabh@school.im', '1994-01-07', 'F', 'BCA', 'Gaming,Sports', 'e8db2825de1ebe591057af83625fe45e.jpg', '', '2018-07-09 12:01:56', 'A', 1, 3, 1),
(62, 'Prasant', '7989789778', 'prasant@sch.ool', '1996-02-02', 'F', 'BCA', 'Music,Gaming', '51d530775d25ea9f53e80f11fc87631f.jpg', '', '2018-07-09 12:02:40', 'A', 1, 3, 1),
(65, 'Rahul', '8888555555', 'rahul_d@not.in', '1988-09-28', 'M', 'MBA', 'Sports', 'a5b4f9c7865662750926e8b0992e3184.jpg', '', '2018-07-09 12:17:08', 'A', 1, 3, 1),
(75, 'Avinash1', '7529965815', 'avi_nash@gmail.inn', '1993-12-29', 'M', 'BCA', 'Music,Gaming', '67dbdcaace29de00e8150f1fa08f5f98.jpg', '', '2018-07-09 14:41:08', 'A', 1, 3, 1),
(81, 'Om_Prakash1', '9089786756', 'Om_Prakash@om.om', '2018-07-17', 'M', 'MBA', 'Music,Sports', 'ef19d7020e00e9d996d9ffc198a9a85f.jpg', '', '2018-07-09 15:03:06', 'A', 1, 3, 1),
(112, 'ddddd', '9569569866', 'ddddd@ddd.dddd', '1988-12-04', 'M', 'BBA', 'Gaming', '22pEM6AWeT2AlhkYCUVmBZlqlexsRwTO5.jpg', '', '2018-07-10 15:44:20', 'A', 1, 3, 1),
(121, 'iphone', '1189893333', 'zzzzz@rr.ii', '1999-05-01', 'F', 'BBA', 'Music,Sports', '44859476f50456b740c4e70771b11faa.jpg', '', '2018-07-10 16:21:03', 'A', 1, 3, 1),
(122, 'vvv1', '7856111222', 'vvv@vvv.yes1', '1988-11-22', 'M', 'BCA', 'Music,Gaming,Sports', '1c442d3b8fe5672f97d3b037b75325b4.jpg', '', '2018-07-10 18:22:04', 'A', 1, 3, 1),
(123, 'wwaaa1', '7856452345', 'admin@www.com', '2001-11-07', 'F', 'BCA', 'Sports', '85w4png7oOX346VXAutVw6SzHzQzBICFU.jpg', '', '2018-07-13 10:45:07', 'A', 1, 3, 1),
(124, 'weee', '5689784589', 'iopio90@www.com', '1996-10-06', 'M', 'BBA', 'Gaming', '46drqfZcF8kWqdjQbzUCTdlGfAUH5OObh.jpg', '', '2018-07-13 10:45:42', 'A', 1, 3, 1),
(125, 'ytyytt1', '7845568945', 'tystyhth@gh.ghch1', '1995-07-18', 'M', 'BBA', 'Music,Gaming', '011de1817de468a67fce8d54d0449b0a.jpg', '', '2018-07-13 12:55:18', 'A', 1, 3, 1),
(130, 'Tybca', '7889788978', 'Tybca@tybca.yuty', '1988-01-03', 'M', 'BBA', 'Gaming', '4036TfNR1ue87MG0v71XLiwshxnewIbnS.jpg', '', '2018-07-16 17:51:34', 'A', 1, 3, 1),
(132, 'nnn1n661', '1200009090', 'ggg@yyy.kkk1', '2018-08-09', 'M', 'BCA', 'Music,Sports', '9da80fe86ab0b129c5a60ae66aa3dd6f.jpg', '', '2018-07-17 15:39:28', 'A', 1, 3, 1),
(133, 'ttttttt', '1245784578', 'tttt@eee.eee', '1996-12-23', 'M', 'BBA', 'Music,Gaming', '48U4XiL3pj9zg3t80V7eWZZUNPdQIVWOO.gif', '', '2018-07-17 17:55:41', 'A', 1, 3, 1),
(134, 'Maihu', '7856785689', 'Yhakoi@nhi.hai', '1998-06-03', 'M', 'BBA', 'Gaming,Sports', 'af5adac5642e80f030c62bd51600ebad.jpg', '', '2018-07-17 18:18:53', 'A', 1, 4, 5),
(135, 'itc', '7897890000', 'itc@itc.itc', '2000-04-04', 'M', 'BBA', 'Gaming', '16XitaaLBlaVrKbAPC6boszNEXMozj4Lg.jpg', '', '2018-07-18 12:04:19', 'A', 1, 3, 3),
(136, 'itcitc', '1231231232', 'itcitc@itcitc.itcitc', '1997-02-04', 'M', 'BBA', 'Sports', '41m3cxo8Jlmpltj5cLmBKG8xbNclJTx7M.jpg', '', '2018-07-18 12:07:12', 'A', 1, 4, 6),
(137, 'iiiiq', '4556455645', 'iiiii@www.www', '1986-12-25', 'M', 'BBA', 'Music,Gaming', '63Yf9MDRxUy3DRDPSdE0aGkGDW6FXWt1x.jpg', '', '2018-07-18 12:11:23', 'A', 1, 3, 4),
(138, 'bbbb', '7777788888', 'bbbbb@nnn.kkk', '1992-03-10', 'M', 'MBA', 'Music,Gaming,Sports', '96CM4CpV9nW5GfFW7hhxMUVjmN3w8yTmN.jpg', '', '2018-07-18 12:12:35', 'A', 1, 3, 2),
(139, 'zzzz1', '1231234564', 'zzz1@zz.yy', '1998-06-02', 'M', 'BBA', 'Music,Gaming', '53EQNPlH1ndWNlJWxAbrqlTbELdw0Aprq.jpg', '', '2018-07-18 12:16:53', 'D', 1, 3, 3),
(140, 'mmm_mv1', '1111111111', 'mmm@mmm.oov1', '1998-11-16', 'M', 'BBA', 'Gaming,Sports', '94008fedee81cb89a025d19c66f0db64.jpg', '', '2018-07-18 12:18:06', 'D', 1, 3, 1),
(141, 'tikkk', '4523564512', 'hello@tikk.nn', '1998-12-12', 'M', 'BBA', 'Gaming', '88BOgp6XYKbfwcMyjlRsJ1Oy7VC6PgoOR.jpg', '', '2018-07-18 12:20:33', 'D', 1, 4, 5),
(142, 'fsffsgfgdf', '7889788978', 'fgdfghdh@fsg.dhfj', '2000-10-09', 'M', 'BCA', 'Gaming,Sports', '82wSjTDYMaP4F76BCayZSsDvAjsP6XxwC.jpg', '', '2018-07-23 11:06:50', 'A', 1, 3, 3),
(143, 'XOKLYLCIDD', '9582787523', '8xfJrQn0@gmail.com', '1992-05-23', 'F', 'BCA', 'Music', 'f22f765e4cca8c0cb9972a46b50bca8d.jpg', '', '2018-07-23 11:09:36', 'D', 1, 3, 1),
(144, 'WDAHLKSK', '8026748065', 'shkjH2LhuONiMQY@gmail.com', '1998-10-06', 'F', 'BCA', 'Music', 'b98d2c90ae80142d8b40edfe01a0a4e8.jpg', '', '2018-07-23 14:45:47', 'D', 1, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shows`
--

CREATE TABLE `shows` (
  `id` int(11) NOT NULL,
  `MId` int(11) NOT NULL,
  `screen` int(11) DEFAULT NULL,
  `slot` int(11) DEFAULT NULL,
  `booked` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slider_id` int(8) NOT NULL,
  `slider_img` varchar(100) NOT NULL,
  `slider_name` varchar(100) NOT NULL,
  `slider_des` varchar(255) DEFAULT NULL,
  `slider_st` varchar(1) NOT NULL DEFAULT 'A',
  `slider_dr` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slider_id`, `slider_img`, `slider_name`, `slider_des`, `slider_st`, `slider_dr`) VALUES
(1, '90ba942848a97a69824befe10a87fb0b.jpg', '1', '1', 'A', '2018-06-20 12:41:29'),
(2, '769787b88344a3ebda289ffc1dcd7b83.jpg', '2', '2', 'A', '2018-06-20 12:41:36'),
(3, '205b44a46b459016704e93c38c36eb87.jpg', '3', '3', 'A', '2018-06-20 12:41:50'),
(4, '77a56127ca318a35838c8490007178e4.jpg', '4', '4', 'A', '2018-06-20 12:41:58'),
(5, '27055f81db8165f71bb2e2a4fbd5c6f9.jpg', '5', '5', 'A', '2018-06-20 12:42:04'),
(6, '87bfb88c2381dab6301e08623fc73293.jpg', '6', '6', 'A', '2018-06-20 12:42:15'),
(7, 'd754d54946f26bc5c98c44f4e7634dac.jpg', '7', '7', 'A', '2018-06-20 13:07:46'),
(8, '62aac3e4c53a5fab85dc6fe063eff6fb.jpg', '8', '8', 'A', '2018-06-20 13:07:54'),
(9, 'eadb068e17698905a29a519b84c04feb.jpg', '9', '9', 'A', '2018-06-20 13:08:05'),
(10, '84b961138187ff362157c1765e9f8ce9.jpg', '10', '10', 'A', '2018-06-20 13:09:23'),
(11, 'da30472068d35d9cae14cc280a26ff0c.jpg', '11', '11', 'A', '2018-06-20 13:09:32'),
(12, '13c5f517a7275fb899903576435352e9.jpg', '12', '12', 'A', '2018-06-20 13:09:42'),
(13, '646de981301aa15590c60e96eb520bdf.jpg', '13', '13', 'A', '2018-06-20 13:09:49'),
(14, 'a22245819b426d620124c3f14fe529be.jpg', '14', '14', 'A', '2018-06-20 13:09:56'),
(15, '4937ec955ff64c3a42119c8e1cc0dcc7.jpg', 'p15', 'p15', 'A', '2018-06-21 10:58:21'),
(16, 'e9d9e9d267a7f5cec5e0f65116fc8b61.jpg', 's16', 's16', 'A', '2018-06-21 10:58:35'),
(17, '3918c928a43a7b0dd69c642d1ae3f324.jpg', 's17', 's17', 'A', '2018-06-21 10:58:52'),
(18, 'cc3257c4f6b196ae06b442adc8c11401.jpg', 's18', 's18', 'A', '2018-06-21 10:59:02'),
(19, 'f3dbdc4cd09cbc9b76d5c20adb3be2b1.jpg', 's19', 's19', 'A', '2018-06-21 10:59:13'),
(20, 'f9070f405d298ebd68ce2deb9291769b.jpg', 's20', 's20', 'A', '2018-06-21 10:59:24'),
(21, '362d1827e2b75d3349bff2e402f1bd8c.jpg', 's21', 's21', 'A', '2018-06-21 10:59:31'),
(22, '70b38b6a875b1b3fc61f8fc68f0094ce.jpg', 'FJFJ', 'FSJFJF', 'A', '2018-06-22 16:11:21'),
(23, '0103bc043775a1eb9bf85b01d58f3491.jpg', 'dfe', 'df', 'A', '2018-06-27 11:34:30'),
(24, 'a0f028e01de22258bcf575d34ce5f589.jpg', 'fgf', 'fgddf', 'A', '2018-06-27 11:34:38'),
(25, '50a26313fe372d469ae517c66fc92533.jpg', 'dfgdf', 'gdfg', 'A', '2018-06-27 11:34:44'),
(26, 'fbfefc902455777083a72eec3cbb3063.jpg', 'dgsf', 'gdfsg', 'A', '2018-06-27 11:34:51'),
(27, 'c7c94c74668c8fcb077ab6e53a4f1ac2.jpg', 'gsg', 'dfgsf', 'A', '2018-06-27 11:34:56');

-- --------------------------------------------------------

--
-- Table structure for table `state_list`
--

CREATE TABLE `state_list` (
  `id_state` int(4) NOT NULL,
  `state_name` varchar(25) NOT NULL,
  `st` varchar(1) NOT NULL DEFAULT 'A',
  `dr` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state_list`
--

INSERT INTO `state_list` (`id_state`, `state_name`, `st`, `dr`) VALUES
(1, 'Gujarat', 'A', '2018-07-17 12:35:14'),
(2, 'Uttar-Pradesh', 'A', '2018-07-17 12:35:14'),
(3, 'Rajsthan', 'A', '2018-07-17 12:35:37'),
(4, 'Tamilnadu', 'A', '2018-07-17 12:35:37'),
(5, 'Madhya Pradesh', 'A', '2018-07-17 16:05:11');

-- --------------------------------------------------------

--
-- Table structure for table `tinyurl`
--

CREATE TABLE `tinyurl` (
  `id` int(11) NOT NULL,
  `long_url` varchar(511) NOT NULL,
  `custom_url` varchar(55) DEFAULT NULL,
  `auto_url` varchar(12) DEFAULT NULL,
  `dr` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tinyurl`
--

INSERT INTO `tinyurl` (`id`, `long_url`, `custom_url`, `auto_url`, `dr`) VALUES
(43, 'www.fb.me', NULL, '-c3tIddTE', '2018-06-14 18:26:29'),
(45, 'www.indeed.co.in', NULL, 'DWIUXfpCK', '2018-06-14 18:27:32'),
(47, 'www.indeed.co.in/surat', NULL, 'tjWk15CID', '2018-06-14 18:28:51'),
(50, 'www.fb.me', NULL, 'n0YeU3wXG', '2018-06-14 19:00:16'),
(54, 'www.crazendemand.com', 'cndhhththt', NULL, '2018-06-15 12:43:01'),
(55, 'https://thememakker.com/templates/falcon/html/invoices.html', 'falcon', 'VSWMSp-sP', '2018-06-15 12:51:00'),
(56, 'http://radixtouch.in/templates/admin/redstar/source/light/invoice_payment.html', 'redstar', '9rNWcYEyy', '2018-06-15 12:58:23'),
(57, 'https://www.google.co.in/search?q=url+shortener&rlz=1C1CHBD_enIN766IN766&oq=url+s&aqs=chrome.1.69i57j0j69i61j69i60j69i61j0.4287j0j7&sourceid=chrome&ie=UTF-8', NULL, 'utUWjBFaP', '2018-06-16 10:38:04'),
(61, 'https://stackoverflow.com/questions/20372394/how-to-disable-ctrlu-using-javascript', 'dfd', NULL, '2018-06-18 16:28:02'),
(62, 'https://www.formget.com/codeigniter-jquery-ajax-post/', NULL, 'WRg-cl66l', '2018-06-18 18:53:40'),
(63, 'https://stackoverflow.com/questions/23911438/how-to-get-data-from-database-using-ajax-in-codeigniter', 'dfaswfgsd', NULL, '2018-06-18 18:54:04'),
(64, 'https://datatables.net/examples/server_side/post.html', 'dfg7675', 'lPbXRjcxG', '2018-06-18 18:54:40'),
(65, 'http://www.indishare.me/c1o52lqlbd7s', NULL, 'VbHzFMThf', '2018-06-19 18:21:26'),
(66, 'https://www.google.com/gmail/about/#', 'q23w', '7fJgY79r1', '2018-06-27 11:11:01');

-- --------------------------------------------------------

--
-- Table structure for table `trydt`
--

CREATE TABLE `trydt` (
  `id` int(8) NOT NULL,
  `firstname` varchar(35) NOT NULL,
  `lastname` varchar(35) NOT NULL,
  `position` varchar(35) NOT NULL,
  `office` varchar(35) NOT NULL,
  `dr` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `st` enum('Y','N') NOT NULL DEFAULT 'Y',
  `img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trydt`
--

INSERT INTO `trydt` (`id`, `firstname`, `lastname`, `position`, `office`, `dr`, `st`, `img`) VALUES
(18, 'Rishabh', 'bjjjudyfu', 'z', 'ilhljnjhou', '2018-06-19 12:49:54', 'Y', 'j.gif'),
(20, 'Prasant', 'dsgygye', 'm', 'jyu yuy', '2018-06-19 12:49:54', 'Y', 'mac.gif'),
(21, 'Jyoti', 'fuhug', 'c', 'iholhol', '2018-06-19 12:49:54', 'Y', ''),
(22, 'Mahi', 'uiuhi', 'i', 'dyttufv g', '2018-06-19 12:49:54', 'Y', ''),
(23, 'Nirala', 'yfgdh', 'ghg', 'hghh hg', '2018-06-19 13:14:36', 'Y', ''),
(24, 'Pal', 'vxbvxb', 'vbv', 'bvvbv', '2018-06-19 18:02:51', 'Y', ''),
(25, 'Vijay', 'vxbvxb', 'vbv', 'bvvbv', '2018-06-19 18:13:39', 'Y', ''),
(26, 'Omkar', '898kkt', 'djhfjhd', '525 juj', '2018-06-20 10:37:45', 'Y', ''),
(27, 'Ajey', 'fdjgjh', 'yuyu', 'hjghj juj', '2018-06-20 10:37:54', 'Y', ''),
(34, 'gautam', 'tt', 'tyt', 'yt', '2018-06-20 11:47:14', 'Y', ''),
(35, 'Tiwari', 'yeywe', 'ywteyty', 'tyty', '2018-06-20 11:47:14', 'Y', ''),
(36, 'Sanjay', 'hyhde', 'jhjui7ir7', 'uruyiu', '2018-06-20 11:47:32', 'Y', ''),
(37, 'Virat', 'rkjk', 'jkjh', 'kgkhk', '2018-06-20 11:47:32', 'Y', ''),
(38, 'Yadav', '8967896', 'ii8i8i', '9898kj', '2018-06-20 11:47:42', 'N', ''),
(39, 'hello', 'namaste', 'no position', 'at udhna', '2018-06-21 11:03:53', 'N', ''),
(40, 'rahul', 'nothing', 'have', 'no office', '2018-06-21 11:03:53', 'Y', ''),
(41, 'avinash', 'kori', 'hacker', 'nanpura', '2018-06-21 11:04:30', 'Y', ''),
(42, 'Raju', 'kaju', 'ok', 'no off', '2018-06-21 18:24:10', 'Y', ''),
(43, 'Ram', 'bhai', 'aa', 'ss', '2018-06-21 18:24:10', 'Y', ''),
(44, 'Rem', 'Vem', 'kem', 'em', '2018-06-21 18:24:30', 'Y', ''),
(45, 'new song', 'ddd', 'ddd', 'dd', '2018-06-22 10:43:59', 'Y', ''),
(46, 'news', 'th', 'hhdgh', 'ghg', '2018-06-22 10:43:59', 'Y', ''),
(47, 'netflix', 'fdfd', 'fgdhg', 'fgg', '2018-06-22 10:43:59', 'Y', ''),
(48, 'netwala', 'fgdh', 'gdhdfsg', 'fgsddg', '2018-06-22 10:43:59', 'Y', ''),
(49, 'net theif', 'dff', 'gfgf', 'gfg', '2018-06-22 10:43:59', 'Y', ''),
(50, 'notting.com', 'ffsgfgf', 'fgfgf', 'gfgf', '2018-06-22 10:43:59', 'Y', ''),
(51, 'nokia', 'gsag', 'fsgfgfg', 'fgfg', '2018-06-22 10:43:59', 'Y', ''),
(52, 'nagaland', 'ghsg', 'shdg', 'hgfhh', '2018-06-22 10:43:59', 'Y', ''),
(53, 'new south movies', 'bsdghh', 'htryt', 'sbgdf', '2018-06-22 10:43:59', 'Y', ''),
(54, 'net worth ', 'fsgfsaf', 'gffg', 'fgfs', '2018-06-22 10:43:59', 'Y', ''),
(55, 'New Connection', 'hjj', 'hhikh', 'rttyr', '2018-06-27 10:45:45', 'Y', '');

-- --------------------------------------------------------

--
-- Table structure for table `updatec`
--

CREATE TABLE `updatec` (
  `id` int(11) NOT NULL,
  `v` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `updatec`
--

INSERT INTO `updatec` (`id`, `v`) VALUES
(1, 10827),
(2, 11642),
(3, 12771),
(4, 15058),
(5, 11051),
(6, 86767),
(7, 61931),
(8, 59218),
(9, 64009),
(10, 79936);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(55) NOT NULL,
  `password` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL DEFAULT 'India',
  `pincode` int(7) NOT NULL,
  `dr` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `country`, `pincode`, `dr`) VALUES
(4, 'jygjy', 'zzzz@zz.zz', 'zzz', 'USA', 0, '2018-06-04 09:32:33'),
(5, 'dfghdfh', 'admin@ss.ss', 'sss', 'USA', 0, '2018-06-22 10:40:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area_list`
--
ALTER TABLE `area_list`
  ADD PRIMARY KEY (`id_area`),
  ADD KEY `city_fk` (`city_fk`),
  ADD KEY `state_fk` (`state_fk`);

--
-- Indexes for table `city_list`
--
ALTER TABLE `city_list`
  ADD PRIMARY KEY (`id_city`),
  ADD KEY `state_fk` (`state_fk`);

--
-- Indexes for table `ctemp`
--
ALTER TABLE `ctemp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `moviedatabase`
--
ALTER TABLE `moviedatabase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`my_id`);

--
-- Indexes for table `shows`
--
ALTER TABLE `shows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `MId` (`MId`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- Indexes for table `state_list`
--
ALTER TABLE `state_list`
  ADD PRIMARY KEY (`id_state`);

--
-- Indexes for table `tinyurl`
--
ALTER TABLE `tinyurl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trydt`
--
ALTER TABLE `trydt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `updatec`
--
ALTER TABLE `updatec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area_list`
--
ALTER TABLE `area_list`
  MODIFY `id_area` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `city_list`
--
ALTER TABLE `city_list`
  MODIFY `id_city` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `ctemp`
--
ALTER TABLE `ctemp`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `moviedatabase`
--
ALTER TABLE `moviedatabase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `my_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;
--
-- AUTO_INCREMENT for table `shows`
--
ALTER TABLE `shows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slider_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `state_list`
--
ALTER TABLE `state_list`
  MODIFY `id_state` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tinyurl`
--
ALTER TABLE `tinyurl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `trydt`
--
ALTER TABLE `trydt`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `updatec`
--
ALTER TABLE `updatec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `area_list`
--
ALTER TABLE `area_list`
  ADD CONSTRAINT `area_list_ibfk_1` FOREIGN KEY (`city_fk`) REFERENCES `city_list` (`id_city`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `area_list_ibfk_2` FOREIGN KEY (`state_fk`) REFERENCES `state_list` (`id_state`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `city_list`
--
ALTER TABLE `city_list`
  ADD CONSTRAINT `city_list_ibfk_1` FOREIGN KEY (`state_fk`) REFERENCES `state_list` (`id_state`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ctemp`
--
ALTER TABLE `ctemp`
  ADD CONSTRAINT `ctemp_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `product` (`id`);

--
-- Constraints for table `shows`
--
ALTER TABLE `shows`
  ADD CONSTRAINT `shows_ibfk_1` FOREIGN KEY (`MId`) REFERENCES `moviedatabase` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
