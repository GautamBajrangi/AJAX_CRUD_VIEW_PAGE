<html><body><table><tbody>
<tr><th>Pro : <?php echo $prod->id?></th></tr>
<tr><td>Name : <img src="<?php echo base_url()?>data/Product/<?php echo $prod->p_img ?>" alt="<?php  $prod->p_img ?>"
  style='height:75px;width:75px;' ></td></tr>
 <tr><td><a href="<?php echo site_url()?>/toC/add2temp/<?php echo $prod->id ?>"><button type="button" >Add</button> </a></td></tr>
</tbody></table>
 <img width="100" height="100" src="https://images-eu.ssl-images-amazon.com/images/G/31/amazonui/loading/loading-4x._CB398267825_.gif" role="presentation" />

</body></html>







