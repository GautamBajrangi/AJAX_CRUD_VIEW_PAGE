<html>
<head>
<title>Chart </title>
<link rel="shortcut icon" href="https://bit.ly/2uCbnne" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.js"  type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>
<body>


<div id="chartContainer" style="height: 360px; width: 100%;"></div>



















<script src="https://canvasjs.com/assets/script/canvasjs.min.js" type="text/javascript"> </script> 
<script type="text/javascript">
var dataSeries = [];
var index = 0;
var chart = new CanvasJS.Chart("chartContainer", {            
  title: {
    text: "MultiSeries Chart from JSON"
  },
  toolTip: {
    animationEnabled: true,
    shared: true
  },
  data: dataSeries
});
        
$.when(
    $.getJSON("https://api.myjson.com/bins/tfcyl", function(result) {      
    		var dps1 = [], dps2 = [], dps3 = [], dps4 = [];
    		for(var i = 0; i < result.length; i++) {
        	switch(result[i].label) {
          	case 'Installation': dps1.push({ x: new Date(result[i].t), y: result[i].y });
            	break;
            case 'Updatation': dps2.push({ x: new Date(result[i].t), y: result[i].y });
            	break;
            case 'LAN': dps3.push({ x: new Date(result[i].t), y: result[i].y });
            	break;
            case 'Conversion': dps4.push({ x: new Date(result[i].t), y: result[i].y });
            	break;
          }
        	//console.log(result[i].label);
        }
        dataSeries.push({type: "spline", dataPoints: dps1});
        dataSeries.push({type: "spline", dataPoints: dps2});
        dataSeries.push({type: "spline", dataPoints: dps3});
        dataSeries.push({type: "spline", dataPoints: dps4});
      })
    ).then(function() {
    chart.render();
 }); 

</script>




</body>
</html>