<!DOCTYPE html>
<html>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<body>
<?php $ty=mt_rand(11,125);$tu=mt_rand(159,2456);  ?>
<div data-ng-app="" data-ng-init="quantity=<?php echo $tu?> ; price=<?php echo $ty?>">

<h2>Cost Calculator</h2>

Quantity: <input type="number" ng-model="quantity">
Price: <input type="number" ng-model="price">

<p><b>Answer :  </b> <strong style="color:#C03">{{quantity / price}}</strong></p>

</div>

</body>
</html>







<div class="container">
      <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
          <div class="panel panel-info" >
                  <div class="panel-heading">
                      <div class="panel-title">Angularjs Login Script using PHP MySQL and Bootstrap</div>

                  </div>

                  <div style="padding-top:30px" class="panel-body" >
                      <form name="login" ng-submit="angCtrl.loginForm()" class="form-horizontal" method="POST">

                          <div style="margin-bottom: 25px" class="input-group">
                                      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                      <input type="email" id="inputemail" class="form-control" required autofocus ng-model="angCtrl.inputData.email">
                          </div>

                          <div style="margin-bottom: 25px" class="input-group">
                                      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                      <input type="password" id="inputpassword" class="form-control" required ng-model="angCtrl.inputData.password">
                          </div>
                          <div class="form-group">
                              <!-- Button -->
                              <div class="col-sm-12 controls">
                                  <button type="submit" class="btn btn-primary pull-left"><i class="glyphicon glyphicon-log-in"></i> Log in</button>
                              </div>
                          </div>
                              <div class="alert alert-danger" ng-show="errorMsg">
                                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                                      ×</button>
                                  <span class="glyphicon glyphicon-hand-right"></span>&nbsp;&nbsp;{{errorMsg}}
                              </div>
                          </form>
                      </div>
                  </div>
      </div>
  </div>