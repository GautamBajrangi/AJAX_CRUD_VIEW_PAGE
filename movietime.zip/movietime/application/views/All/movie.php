<title>Movie Time</title>
<h1 align="center">Hello welcome to MovieBook.com</h1>
<br>
<br>


<h4 align="center">Sign Up </h4> 
<table align="center" border="2" >
<form name="f1" id="f1" method="post" enctype="multipart/form-data" 
action="<?php echo site_url()?>/movietime/register">

<tr>
<td>Email</td>
<td><input type="email" name="email" id="email" required></td>
</tr>

<tr>
<td>Name</td>
<td><input type="text" name="name" id="name" required></td>
</tr>

<tr>
<td>Password</td>
<td><input type="password" name="password" id="password" required></td>
</tr>

<tr>
<td>Country</td>
<td>
<select name="country"> 
<option value="India" selected>India</option>
<option value="UK">UK</option>
<option value="USA">USA</option>
</select>
</td>
</tr>
	
<td colspan="2" align="center"><button type="submit" id="sub"  >Register 
</button></td>



</form>

</table>



<h4 align="center">Log In </h4> 
<table align="center" border="2" >
<form name="f2" id="f2" method="post" enctype="multipart/form-data" action="<?php echo site_url()?>/movietime/login">

<tr>
<td>Email</td>
<td><input type="email" name="emailv" id="email" required></td>
</tr>



<tr>
<td>Password</td>
<td><input type="password" name="pass" id="password" required></td>
</tr>

	
<td colspan="2" align="center"><button type="submit" id="sub"  >Log In 
</button></td>



</form>

</table>