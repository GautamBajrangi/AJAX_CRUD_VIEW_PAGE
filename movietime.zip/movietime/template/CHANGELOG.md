v1.0.0 21 Sept, 2016 - Initial Release

v1.1.0 10 Nov, 2016 - New Page Added
- fix link in documentation
- for those who want to upsell inside their dashboard we added a new page "Upgrade to PRO" with a pricing and options table

v1.1.1 8 Feb 2017
- switched to MIT License

v1.2.0 8 Sep 2017
- added PerfectScrollbar for windows better scroll
- added arrive.js library for dynamic content
- fix issue with charts when resizing window
- change size of buttons for notifications on mobile
- added pagination style
- fixed issue with Bootstrap modal
- added fixed navbar
- documentation updates
- minor design fixes
