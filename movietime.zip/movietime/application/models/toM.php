<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class toM extends CI_Model {

	public function __construct()
	{ parent:: __construct();

		$this->load->model('movietimeM');$this->load->model('toM');
		date_default_timezone_set('asia/kolkata');
	}

	
	public function get_mydata()
	{
		return $this->db->get('trydt')->result();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}?>