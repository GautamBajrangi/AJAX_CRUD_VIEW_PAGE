Fontawesome Pro 5 For ProcessWire
=====================================

This module facilitates the use of Fontawesome Pro 5 for use in the ProcessWire admin.

Instructions:

1) Download your copy of Fontawesome Pro 5 from the private repo.
2) Place the css, js, sprites and webfonts folders inside a folder called 'vendor' in the module directory.


4) Install the module and select which style to use, webfonts or svg-framework.

