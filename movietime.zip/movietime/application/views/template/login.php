
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url()?>/assets/img/apple-icon.png" />
    <link rel="icon" type="image/png" href="<?php echo base_url()?>/assets/img/favicon.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Material Dashboard by Creative Tim</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url()?>/assets/css/bootstrap.min.css" rel="stylesheet" />
    <!--  Material Dashboard CSS    -->
    <link href="<?php echo base_url()?>/assets/css/material-dashboard.css?v=1.2.0" rel="stylesheet" />
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url()?>/assets/css/demo.css" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>
</head>

<body>
        

        <div class="main-panel">
           
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header" data-background-color="purple">
                                    <h4 class="title">Sign Up </h4>
                                     </div>
                                <div class="card-content">
                                    <form name="f1" id="f1" enctype="multipart/form-data" action="<?php echo site_url()?>/movietime/register" method="post">
                                       
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Email Address</label>
                                                    <input type="text" class="form-control" name="email" required>
                                                </div>
                                            </div></div>
                                             <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Full Name</label>
                                                    <input type="text" class="form-control" name="name" required>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Password</label>
                                                    <input type="password" class="form-control" name="password" required>
                                                </div>
                                            </div></div>
                                            
                                            

                                             <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Country</label>
                                                    <select name="country" class="form-control">
                                                    <option value="India" selected>India</option>
                                                    <option value="USA"> USA</option>
                                                    <option value="China"> China</option>
                                                    </select>
                                                </div></div>
                                            </div>

                                             <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Zip Code</label>
                                                    <input type="number" min="100000" class="form-control" name="zip" maxlength="6" required>
                                                </div>
                                            </div>
                                        </div>
                                       
                                        <button type="submit" class="btn btn-primary pull-middle">Register</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            
            
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header" data-background-color="purple">
                                    <h4 class="title">Log In </h4>
                                    
                                </div>
                                <div class="card-content">
                                    <form name="f2" id="f2" enctype="multipart/form-data" method="post">
                                       
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Email Address</label>
                                                    <input type="text" class="form-control" name="emailv" id="emailv">
                                                     <p style="color:red" id="eml"></p>
                                                </div>
                                            </div></div>
                                             
                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Password</label>
                                                    <input type="password" class="form-control" name="pass" id="pass">
                                                    <p style="color:red" id="psl"></p>
                                                </div>
                                            </div></div>
                                   
                                       
                                        <button type="submit" class="btn btn-primary pull-middle"  id="btnsubmit" onClick="return validate()">Log In</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
          
        </div>
    </div>
</body>


<script>
function validate()
{
var email=document.getElementById("emailv").value;  
var password=document.getElementById("pass").value;

 if(email=="")
{
	$("#eml").html("Enter Email Address");
	document.f2.emailv.focus() ;
	return false;
}
 

else if(password=="")
{
	$("#psl").html("Enter Password");
	document.f2.pass.focus() ;
	return false;
}
else
{
document.getElementById('f2').action="<?php echo site_url()?>/movietime/login" ;
}
}


</script> 


<!--   Core JS Files   -->
<script src="<?php echo base_url()?>/assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>/assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>/assets/js/material.min.js" type="text/javascript"></script>
<!--  Charts Plugin -->
<script src="<?php echo base_url()?>/assets/js/chartist.min.js"></script>
<!--  Dynamic Elements plugin -->
<script src="<?php echo base_url()?>/assets/js/arrive.min.js"></script>
<!--  PerfectScrollbar Library -->
<script src="<?php echo base_url()?>/assets/js/perfect-scrollbar.jquery.min.js"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo base_url()?>/assets/js/bootstrap-notify.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Material Dashboard javascript methods -->
<script src="<?php echo base_url()?>/assets/js/material-dashboard.js?v=1.2.0"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo base_url()?>/assets/js/demo.js"></script>

</html>