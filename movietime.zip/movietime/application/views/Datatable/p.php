<html>
<head>
<title>DataTable</title>
<!-- Latest compiled and minified CSS /c1o52lqlbd7s -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css"  >
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/jquery.dataTables.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.transitions.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.transitions.min.css">


<style>
 #owl-demo1 .item img{
        display: block;
        width: 100%;
        height: auto;
    } 
    </style>

<!--link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-treegrid/0.2.0/css/jquery.treegrid.css"-->
    <style>
	 #owl-demo .item{
      margin: 3px;
    }
    #owl-demo .item img{
      display: block;
      width: 100%;
      height: auto;
    }</style>
    
</head>
<body>

    <div id="owl-demo1" class="owl-carousel owl-theme">
     <?php foreach($Slider as $s) { ?>
      <div class="item"><img src="<?php echo base_url()?>data/Slider/<?php echo $s->slider_img ?>" alt="<?php  $s->slider_img ?>" ></div>
   
      <?php } ?>
     
    </div>

<br><br>

     <div id="owl-demo" class="owl-carousel ">
     <?php foreach($Pro as $p) { ?>
      <div class="item"><?php  $p->p_name ?><img data-src="<?php echo base_url()?>data/Product/<?php echo $p->p_img ?>" alt="<?php  $p->p_img ?>" 
       class="lazyOwl" ></div>
    
	  <?php } ?>
    </div>
     

<br><br>



</body>
</html>
<script src="https://code.jquery.com/jquery-3.3.1.js"  type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"  type="text/javascript"></script>
<!--script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-treegrid/0.2.0/js/jquery.treegrid.js"  type="text/javascript"></script-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>


<script type="text/javascript" >
 $(document).ready(function() {
     
      $("#owl-demo").owlCarousel({
        items : 7,
        lazyLoad : true,
        navigation : true
      }); 
     
    });

</script>
<script type="text/javascript" >
 $(document).ready(function() {
  $("#owl-demo1").owlCarousel ({
	  
   navigation : true, // Show next and prev buttons
   slideSpeed : 300,
     paginationSpeed : 400,
    singleItem:true,
	 navigation: true,
	     itemsDesktop : [1499,4],
      itemsDesktopSmall : [1199,3],
      itemsTablet : [899,2],
      itemsMobile : [599,1],
      navigation : true,
      navigationText : ['<span class="fa-stack"><i class="fa fa-circle fa-stack-1x"></i><i class="fa fa-chevron-circle-left fa-stack-1x fa-inverse"></i></span>','<span class="fa-stack"><i class="fa fa-circle fa-stack-1x"></i><i class="fa fa-chevron-circle-right fa-stack-1x fa-inverse"></i></span>'],
	 
	
     
          // "singleItem:true" is a shortcut for:
          // items : 1, 
          // itemsDesktop : false,
          // itemsDesktopSmall : false,
          // itemsTablet: false,
          // itemsMobile : false
      });
    });
</script>