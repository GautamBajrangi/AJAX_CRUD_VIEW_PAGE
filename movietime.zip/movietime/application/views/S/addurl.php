<html>
<head>
<title>Bitly</title>
<strong style="color:#F33" >
<h2 align="center">Making Like Bitly.com !!</h2>
</strong>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--link href="https://fonts.googleapis.com/css?family=Rum+Raisin" rel="stylesheet">
<style>
body {
	font-family: 'Rum Raisin', sans-serif;
	font-size: 16px;
}
</style-->

<strong style="color:blue" >
<h2 align="center">Making Like Bitly !!  <button form="f1" class="btn btn-primary"  name="create" >Submit_</button></h2>
</strong>

</head>
<body >
<table class="table-hover" >
  <div class="container">
    <h2> www.Bitly.com </h2>
    <form name="f1" id="f1" method="post"   action="<?php echo site_url()?>/toC/Generate_custom_url" enctype="multipart/form-data">
      <div class="row">
        <div class="form-group col-sm-7">
          <?php if(($this->session->tempdata('YOUR_URL')!="")  && ($this->session->tempdata('tiny')!="") ) { ?>
          <label for="url"> <?php echo "Your URL : ". ($this->session->tempdata('YOUR_URL')).  "<br> After Shorten : " .($this->session->tempdata('tiny')); ?>
            <?php } ?>
          </label>
        </div>
      </div>
      <div class="row">
        <div class="form-group col-sm-7">
          <label for="url"><strong style="color: #00F" >Link : </strong></label>
          <input type="text" class="form-control" id="link" placeholder="Paste Your Long Link Here to Shorten !!! " name="long_url" required>
        </div>
      </div>
      <div class="button clearfix" ></div>
      <div class="row">
        <div class="form-group  col-sm-3">
          <label for="pwd" id=""><strong style="color:#F33" title="Generate Custon URL !!" >Custon URL: </strong> </label>
          <input type="text" class="form-control"  id="custom_url" placeholder="Custon URL" name="custom_url"  >
        </div>
      </div>
      
      <div class="checkbox">
        <input type="checkbox" class="checkbox"  id="chk"  name="chk" value="both"  >
        Create Both </div>
      <button type="submit" class="btn btn-primary" id="create"  name="create" >Generate</button>
        <button type="button" class="btn btn-info" id="print"  name="print" onClick="javascript:window.print();" >Print <i class="fa fa-print"></i></button>
      
    </form>
  </div>
</table>
</body>
</html>

<!--<script>
window.onload=hideform;
function hideform(){ $("#byt").hide(); $("#btn2").hide(); $("#selectid").hide();
$("#lblcity").hide();$("#lblname").hide();$("#lblpwd").hide();$("#lblmob").hide();
$("#name").hide();$("#pwd").hide();$("#mob").hide(); }

function showReg(){ $("#byt").show(); $("#btn1").hide(); }function showSel(){ $("#selectid").show();$("#lblcity").show(); }
function showName(){ $("#name").show();$("#lblname").show(); }
function showPass(){ $("#pwd").show(); $("#lblpwd").show(); } function showMob(){ $("#mob").show();$("#lblmob").show(); }
function hideform2(){ $("#pwd").hide();$("#btn1").hide();$("#btn2").show();}function hideform3(){ $("#pwd").show(); $("#btn1").show();$("#btn2").hide();}

</script-->

<html>
<head>
<title>DataTables example</title>
<link rel="stylesheet" href="<?php echo base_url()?>assets/datatable/datatables.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/datatable/datatables.css">
<link rel="stylesheet" href="<?php echo base_url()?>assets/datatable/css/jquery.dataTables.min.css">
</head>
<body>
<table id="example"  class="display" style="width:80%">
  <thead >
    <tr>
      <th>ID <i class="fa fa-car"></i></th>
      <th>Custom URL</th>
      <th>Auto URL</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody >
    <?php foreach($sbkuch as $tt) { ?>
    <tr id="first">
      <td><button type="button" id="btn" onClick="deleteok(<?php echo $tt->id ?>);"><?php echo $tt->id;?></button></td>
      <td><?php $small = substr($tt->long_url, 0, 4); echo ucwords($small) ?></td>
      <td><a href="<?php echo $tt->long_url?>" target="_new" ><?php if($tt->custom_url!="") { ?>www.go_url.com/<?php echo $tt->custom_url ?><?php } ?></a></td>
      <td><?php echo $tt->custom_url;?></td>
     
      <td><a href="<?php if(ucwords($small)=="Www.") { ?>https://<?php } ?><?php echo $tt->long_url?>" target="_new" >
	  <?php if($tt->auto_url!="") { ?>www.go_url.com/<?php echo $tt->auto_url ?><?php } ?></a></td>
      <td><a href="<?php echo site_url()?>/toC/go/<?php if($tt->auto_url!="" && $tt->custom_url=="") { echo $tt->auto_url ;} else if($tt->custom_url!="" && $tt->auto_url==""){ echo $tt->custom_url ;}  else if($tt->auto_url!="" && $tt->custom_url!="") { echo $tt->custom_url ;}  ?>" ><?php echo "Click";?></a></td>
      
     </tr>
     
     
      <?php } ?>
    
  </tbody>
</table>

<div class="clearfix"></div>
</body>
</html>

<!-- jQuery library -->


<script src="<?php echo base_url()?>assets/datatable/js/jquery.dataTables.min.js"  type="text/javascript"></script>
<script type="text/javascript" class="init">

	$(document).ready(function() {
	$('#example').DataTable();
	//"paging":   false,
        //"ordering": false,
        //"info":     false
	} );
				
				
</script>

  <script>
 	function deleteok(data){
				$.ajax({
							url:"<?php echo site_url() ?>/toC/delete_url/"+data,
							success: function(ok){ 	alert(" 1 row deleted !!!"); }
					});
			}
			
document.onkeydown = function(e) {
        	if (e.ctrlKey && (e.keyCode === 67 ||  e.keyCode === 86 || e.keyCode === 85 ||   e.keyCode === 117))
			{ return false;  } else {  return true; }};
			</script>